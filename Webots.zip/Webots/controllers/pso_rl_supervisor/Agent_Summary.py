import pandas as pd
import matplotlib.pyplot as plt

# --- IMPORTANT: Define your CSV file path and column names here ---
file_path ='E:\\Webots\\controllers\\pso_rl_supervisor\\agent_simulation_summary.csv'

# Replace these with the actual column names from your CSV file
agent_id_column = 'AgentID'  # Column for Agent identifiers (X-axis)
distance_column = 'TotalDistanceTraveled_Iterations' # Column for total distance traveled (Y-axis of 1st graph)
targets_column = 'TargetsCollected' # Column for targets collected (Y-axis of 2nd graph)

try:
    # Read the CSV file
    df = pd.read_csv(file_path)

    if df.empty:
        print(f"The CSV file at {file_path} is empty.")
    else:
        # --- Validate required columns ---
        required_columns = []
        if agent_id_column: # If None, we'll use DataFrame index
            required_columns.append(agent_id_column)
        required_columns.extend([distance_column, targets_column])
        
        missing_columns = [col for col in required_columns if col and col not in df.columns]
        if missing_columns:
            print(f"Error: The following required columns are missing from your CSV: {', '.join(missing_columns)}")
            print(f"Please ensure your CSV file ('{file_path}') contains these columns, or update the script variables.")
        else:
            # Determine X-axis values
            if agent_id_column:
                x_values = df[agent_id_column]
            else:
                # Use row index as agent IDs if no agent_id_column is specified
                x_values = df.index 
                print(f"Using row numbers as Agent IDs since 'agent_id_column' was not specified or was None.")


            # --- Figure 1: Distance Traveled by Each Agent ---
            plt.figure(1, figsize=(10, 6)) # Create a new figure (window 1)
            plt.bar(x_values, df[distance_column], color='orange', label='Total Distance')
            plt.xlabel('Agent')
            plt.ylabel('Total Distance Traveled')
            plt.title('Distance Traveled by Each Agent')
            plt.xticks(rotation=45, ha="right") # Rotate x-axis labels if they are long
            plt.grid(axis='y', linestyle='--')
            plt.tight_layout() # Adjust layout to prevent labels from overlapping

            # --- Figure 2: Targets Reached by Each Agent ---
            plt.figure(2, figsize=(10, 6)) # Create a new figure (window 2)
            plt.bar(x_values, df[targets_column], color='green', label='Targets Collected')
            plt.xlabel('Agent')
            plt.ylabel('Targets Reached')
            plt.title('Targets Reached by Each Agent')
            plt.xticks(rotation=45, ha="right") # Rotate x-axis labels
            plt.grid(axis='y', linestyle='--')
            plt.tight_layout()

            # Show both plots
            plt.show()

except FileNotFoundError:
    print(f"Error: The file '{file_path}' was not found.")
    print("Please ensure the file path is correct and the file exists.")
except pd.errors.EmptyDataError:
    print(f"Error: The CSV file '{file_path}' is empty.")
except KeyError as e:
    print(f"Error: A data column was not found in the CSV: {e}.")
    print(f"Please check the 'agent_id_column', 'distance_column', and 'targets_column' variables in the script and your CSV file header.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

