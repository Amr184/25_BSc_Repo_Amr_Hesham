import pandas as pd
import matplotlib.pyplot as plt
import os

csv_file_path = 'E:\\Webots\\controllers\\pso_rl_supervisor\\rl_pretraining_progress.csv'
if not os.path.exists(csv_file_path):
    print(f"Error: The file '{csv_file_path}' was not found.")
    print("Please make sure the CSV file is in the same directory as the script.")
else:
    try:
        df = pd.read_csv(csv_file_path)
        plt.style.use('seaborn-v0_8-darkgrid')
        fig, axes = plt.subplots(2, 1, figsize=(10, 15), sharex=True)

        # Plot 1: Total Reward
        axes[0].plot(df['Episode'], df['Cumulative_Reward'], label='Total Reward per Episode', color='skyblue')
        axes[0].set_ylabel('Total Reward')
        axes[0].set_title('RL Pre-training Progress')
        axes[0].legend()
        axes[0].grid(True)
        
        # Plot 2: Epsilon Value per Episode
        axes[1].plot(df['Episode'], df['Epsilon'], label='Epsilon', color='green')
        axes[1].set_ylabel('Epsilon Value')
        axes[1].set_xlabel('Episode Number')
        axes[1].legend()
        axes[1].grid(True)
        plt.tight_layout()

        plt.show()

    except Exception as e:
        print(f"An error occurred while reading or plotting the CSV file: {e}")