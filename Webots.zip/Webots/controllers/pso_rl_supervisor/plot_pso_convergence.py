import matplotlib.pyplot as plt
import pandas as pd
import os

try:
    
    df = pd.read_csv('E:\\Webots\\controllers\\pso_rl_supervisor\\initial_pso_fitness.csv')
   
    plt.figure(figsize=(10, 6))
    plt.plot(df['PSO_Iteration'], df['Global_Best_Fitness'])
    plt.xlabel('PSO Iteration')
    plt.ylabel('Global Best Fitness')
    plt.title('PSO Convergence (Initial Allocation)')
    plt.grid(True)
    plt.show()

except FileNotFoundError:
    print("Error: initial_pso_fitness.csv not found. Run the Webots simulation first.")
except Exception as e:
    print(f"An error occurred: {e}")










    