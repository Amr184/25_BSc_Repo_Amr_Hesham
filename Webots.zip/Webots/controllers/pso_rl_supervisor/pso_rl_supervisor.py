from controller import Supervisor
import numpy as np
import random
import time
import math
import csv

GRID_SIZE = 20
CELL_SIZE = 0.2
ACTIONS = [(0, 1), (1, 0), (0, -1), (-1, 0)]
ACTION_SYMBOLS = ['N', 'E', 'S', 'W']

AGENT_START_POSITIONS = [(19,0),(0, 19),(0,0)]#,(0,0),(0,0)

ALPHA = 0.7
GAMMA = 0.9

PRETRAINING_EPISODES = 4000
PRETRAINING_ITERATIONS_PER_EPISODE = 1000
EPSILON_PRETRAIN_START = 0.9
EPSILON_PRETRAIN_END = 0.15

EPSILON_EXECUTION = 0

NUM_AGENTS = 2
NUM_TARGETS = 52
OBSTACLES = []#(2, 3), (3, 3), (4, 3), (5, 3), (7, 7), (8, 2), (1, 8) ,,,(7, 15),(7, 13),(7, 11),(7, 9)

AGENT_NAMES = [f"AGENT_{i}" for i in range(NUM_AGENTS)]
TARGET_BOXES_INITIAL = [f"box{i+1}" for i in range(NUM_TARGETS)]
ADDITIONAL_BOXES = ["box54", "box55"]#"box6", "box7", "box8", "box9", "box10","box53", "box54", "box55"
HIDE_POSITION = [6, 1.35, 0.026]
OBSTACLE_NODES = ["obs1", "obs2", "obs3", "obs4"] #"obs1", "obs2", "obs3", "obs4", "obs5", "obs6", "obs7"
PREDEFINED_DYNAMIC_TARGET_POSITIONS = [(3,3),(10,17)]#for testing (1, 1), (2,2), (3,3),(3,3),(10,17)

P1_REMAINING_TIME = 90
P2_REMAINING_TIME = 120
P3_REMAINING_TIME = 150
DEADLOCK_ATTEMPT_THRESHOLD = 3 

MIN_COLLECTION_TIME = 0
MAX_COLLECTION_TIME = 0

target_collection_times = []
target_current_collection_times = []
target_remaining_times = []

MAX_ADDITIONAL_TARGETS = len(ADDITIONAL_BOXES)
SPAWN_INTERVAL_RANGE = (1, 1)

NUM_PARTICLES = 50
MAX_VELOCITY = 2.0
INERTIA_WEIGHT_START = 0.9
INERTIA_WEIGHT_END = 0.4
C1 = 2.0
C2 = 2.0
PSO_ITERATIONS_INITIAL = 100
PSO_ITERATIONS_REALLOC = 100



DYNAMIC_TARGET_EXPIRY_TIMES_SECONDS = [0.96, 0.96, 0.96, 0.96, 0.96] 

targets = []
collected = []
collected_by = []
robots = []
task_allocation = []
target_current_collection_times = [0] * len(targets)

NEW_TARGETS_POOL = []
dynamic_targets_spawned_count = 0
next_dynamic_spawn_time = -1
dynamic_spawn_interval_steps = -1

DYNAMIC_SPAWN_INTERVAL_MIN_STEPS = 30 
DYNAMIC_SPAWN_INTERVAL_MAX_STEPS = 30

prev_collected_status = []
prev_target_remaining_times = []
expired_target_messages_printed = set() 
timestep = -1



RELEARNING_EPISODES = 1000  
RELEARNING_ITERATIONS_PER_EPISODE = 1000 
EPSILON_RELEARN_START = 0.9 
EPSILON_RELEARN_END = 0.15

RL_CONVERGENCE_WINDOW_SIZE_PRETRAIN = 200  
RL_CONVERGENCE_THRESHOLD_PRETRAIN = 5.0    
RL_CONVERGENCE_WINDOW_SIZE_RETRAIN = 100   
RL_CONVERGENCE_THRESHOLD_RETRAIN = 5.0  

def get_grid_position_from_coords(coords):
    x = min(max(int(coords[0] / CELL_SIZE), 0), GRID_SIZE - 1)
    y = min(max(int(coords[1] / CELL_SIZE), 0), GRID_SIZE - 1)
    return (x, y)

def get_coords_from_grid_position(grid_pos):
    x, y = grid_pos
    return [(x + 0.5) * CELL_SIZE, (y + 0.5) * CELL_SIZE, 0.0019]

def is_valid_grid_position(grid_pos):
    x, y = grid_pos
    return 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE and (x, y) not in OBSTACLES

def generate_targets(num_targets, existing_taken_positions):
    generated_targets = []
    taken_positions = set(existing_taken_positions)
    while len(generated_targets) < num_targets:
        tx, ty = random.randint(0, GRID_SIZE - 1), random.randint(0, GRID_SIZE - 1)
        if (tx, ty) not in taken_positions and is_valid_grid_position((tx, ty)):
            generated_targets.append((tx, ty))
            taken_positions.add((tx, ty))
    return generated_targets

def spawn_boxes(target_positions, box_names):
    for i, target in enumerate(target_positions):
        if i < len(box_names):
            box_node = supervisor.getFromDef(box_names[i])
            if box_node:
                box_translation = box_node.getField('translation')
                x, y = target
                box_translation.setSFVec3f([((x + 0.5) * CELL_SIZE) + 0.06, ((y + 0.5) * CELL_SIZE) + 0.06, 0.025])


def spawn_boxes2(target_positions, box_names):
    for i, target in enumerate(target_positions):
        if i < len(box_names):
            box_node = supervisor.getFromDef(box_names[i])
            if box_node:
                box_translation = box_node.getField('translation')
                x, y = target
                box_translation.setSFVec3f([((x + 0.5) * CELL_SIZE) , ((y + 0.5) * CELL_SIZE), 0.05])

def hide_box(box_name):
    box_node = supervisor.getFromDef(box_name)
    if box_node:
        box_translation = box_node.getField('translation')
        box_translation.setSFVec3f(HIDE_POSITION)

def get_unassigned_targets(agent_id, allocation, all_targets, collected_status):
    unassigned = []
    num_current_targets = len(all_targets)
    current_allocation = list(allocation) + [-1] * max(0, num_current_targets - len(allocation))

    for target_id in range(num_current_targets):
        if not collected_status[target_id] and (target_id >= len(current_allocation) or current_allocation[target_id] != agent_id):
             unassigned.append(all_targets[target_id])
    return unassigned

def estimate_travel_time(start_pos, end_pos):
    return abs(start_pos[0] - end_pos[0]) + abs(start_pos[1] - end_pos[1])

def is_target_feasible(target_id, agents, all_targets, all_target_remaining_times, all_target_collection_times):
    if target_id >= len(all_targets) or target_id >= len(all_target_remaining_times) or target_id >= len(all_target_collection_times):
        return False

    target_pos = all_targets[target_id]
    target_remaining_time_steps = all_target_remaining_times[target_id]
    target_collection_time_steps = all_target_collection_times[target_id]

    if target_remaining_time_steps <= 0:
        return False

    for agent in agents:
        if agent.is_collecting and agent.currently_collecting == target_id:
             return True
        travel_time_grid_steps = estimate_travel_time(agent.grid_pos, target_pos)
        travel_time_simulation_steps = travel_time_grid_steps

        estimated_total_time_steps = travel_time_simulation_steps + target_collection_time_steps

        if estimated_total_time_steps <= target_remaining_time_steps:
            return True

    return False

def get_nearest_neighbor_order(start_pos, target_ids, all_targets, all_target_remaining_times, all_target_collection_times):
    if not target_ids:
        return [], 0, 0.0 

    current_pos = start_pos

    remaining_target_ids = list(target_ids)
    ordered_target_ids = []
    estimated_total_time_steps = 0.0
    actual_travel_distance_for_sequence = 0.0 

    while remaining_target_ids:
        next_target_id = None
        min_priority_metric = (float('inf'), float('inf'))

        for target_id_candidate in remaining_target_ids:
            if not (target_id_candidate < len(all_targets) and \
                    target_id_candidate < len(all_target_remaining_times) and \
                    target_id_candidate < len(all_target_collection_times)):
                continue

            target_pos_candidate = all_targets[target_id_candidate]
            target_remaining_time_candidate = all_target_remaining_times[target_id_candidate]
            target_collection_time_candidate = all_target_collection_times[target_id_candidate]
            if target_remaining_time_candidate <= 0:
                continue

            travel_time_to_candidate_grid_steps = estimate_travel_time(current_pos, target_pos_candidate)
            travel_time_to_candidate_sim_steps = float(travel_time_to_candidate_grid_steps)
            estimated_completion_time_for_this_task_if_next = estimated_total_time_steps + travel_time_to_candidate_sim_steps + target_collection_time_candidate
            current_eval_metric = (target_remaining_time_candidate, estimated_completion_time_for_this_task_if_next)

            if current_eval_metric < min_priority_metric:
                min_priority_metric = current_eval_metric
                next_target_id = target_id_candidate

        if next_target_id is not None:
            ordered_target_ids.append(next_target_id)
            remaining_target_ids.remove(next_target_id)
            travel_to_chosen_target_sim_steps = float(estimate_travel_time(current_pos, all_targets[next_target_id]))
            collection_time_of_chosen_target = all_target_collection_times[next_target_id]

            actual_travel_distance_for_sequence += travel_to_chosen_target_sim_steps 
            
            estimated_total_time_steps += travel_to_chosen_target_sim_steps 
            estimated_total_time_steps += collection_time_of_chosen_target   
            
            current_pos = all_targets[next_target_id]
        else:
            break

    return ordered_target_ids, estimated_total_time_steps, actual_travel_distance_for_sequence



class Agent:
    def __init__(self, name, agent_id):
        self.name = name
        self.id = agent_id
        self.node = supervisor.getFromDef(name)
        self.translation = self.node.getField('translation')
        self.rotation = self.node.getField('rotation')
        self.grid_pos = AGENT_START_POSITIONS[self.id]
        self.assigned_targets = [] 
        self.collected_targets = []
        self.Q_table = np.zeros((GRID_SIZE, GRID_SIZE, GRID_SIZE, GRID_SIZE, len(ACTIONS)))


        self.position_history = []
        self.stuck_counter = 0
        self.is_stuck = False
        self.max_history = 10

        self.all_assigned_targets_collected = False
        self.currently_collecting = None
        self.total_collection_time = 0
        self.is_collecting = False
        self.iterations_moved = 0
        self.last_attempted_blocked_cell_by_agent = None
        self.consecutive_attempts_on_same_blocked_cell = 0



    def set_webots_position(self, grid_pos):
        self.grid_pos = grid_pos
        self.translation.setSFVec3f(get_coords_from_grid_position(grid_pos))
        self.rotation.setSFRotation(self.rotation.getSFRotation())

    def update_stuck_status(self):
        if self.all_assigned_targets_collected or self.is_collecting:
             self.is_stuck = False
             self.position_history = []
             self.stuck_counter = 0
             return False

        self.position_history.append(self.grid_pos)
        if len(self.position_history) > self.max_history:
            self.position_history.pop(0)

        self.is_stuck = False
        if len(self.position_history) >= self.max_history:
            unique_positions = set(tuple(pos) for pos in self.position_history)
            if len(unique_positions) <= 2: 
                 self.stuck_counter += 1
            else:
                 self.stuck_counter = 0

        if self.stuck_counter >= 3: 
             self.is_stuck = True

        return self.is_stuck

    def reset_stuck_status(self):
        self.stuck_counter = 0
        self.is_stuck = False
        self.position_history = []

    def choose_action(self, current_epsilon_value, assigned_target_pos):
        if self.is_collecting: 
            return -1

        if assigned_target_pos is None: 
             return random.randint(0, len(ACTIONS) - 1)

        current_state = (self.grid_pos[0], self.grid_pos[1], assigned_target_pos[0], assigned_target_pos[1])
        current_Q = self.Q_table
        if random.random() < current_epsilon_value:
            return random.randint(0, len(ACTIONS) - 1) 
        else:
            q_values = current_Q[current_state]
            
            if current_epsilon_value > 0:
                q_values = q_values + np.random.uniform(-0.001, 0.001, size=len(ACTIONS)) 
            return int(np.argmax(q_values)) 

    def get_next_position(self, action):
        if action == -1: return self.grid_pos 
        dx, dy = ACTIONS[action]
        nx, ny = self.grid_pos[0] + dx, self.grid_pos[1] + dy
        return (nx, ny)

    def is_move_valid(self, next_pos, occupied_positions):
        if not (0 <= next_pos[0] < GRID_SIZE and 0 <= next_pos[1] < GRID_SIZE):
            return False
        if next_pos in OBSTACLES:
            return False
        if next_pos in occupied_positions: 
            return False
        return True

    def move(self, action, occupied_positions, simulate_move_only=False):
        
        if self.all_assigned_targets_collected or self.is_collecting or action == -1:
            return False
        next_pos = self.get_next_position(action)
        if self.is_move_valid(next_pos, occupied_positions):
            self.grid_pos = next_pos
            if not simulate_move_only: 
                self.set_webots_position(self.grid_pos)
                self.iterations_moved += 1
            return True
        else:
            return False
       
       
    

    def update_q_value(self, old_pos, action, reward, new_pos, assigned_target_pos):
        if action == -1: return
        if assigned_target_pos is None: return 

        old_state = (old_pos[0], old_pos[1], assigned_target_pos[0], assigned_target_pos[1])
        new_state = (new_pos[0], new_pos[1], assigned_target_pos[0], assigned_target_pos[1])

        if not (0 <= action < len(ACTIONS)): return 
        current_Q = self.Q_table
        max_next_q = np.max(current_Q[new_state]) 
        current_q = current_Q[old_state][action] 

        
        current_Q[old_state][action] = (1 - ALPHA) * current_q + ALPHA * (reward + GAMMA * max_next_q)

    def get_uncollected_targets(self, all_targets, collected_status):
        uncollected = []
        for tid in self.assigned_targets:
            if tid < len(all_targets) and not collected_status[tid]:
                 uncollected.append(all_targets[tid])
        return uncollected

    def get_next_target_pos(self, all_targets, collected_status):
        
        for tid in self.assigned_targets:
            if tid < len(all_targets) and not collected[tid]:
                
                if tid < len(target_remaining_times) and target_remaining_times[tid] <= 0 and not (self.is_collecting and self.currently_collecting == tid):
                     continue
                return all_targets[tid]
        return None 

    def update_assigned_targets_collected_status(self, collected_status):
        
        
        self.assigned_targets = [
            tid for tid in self.assigned_targets
            if tid < len(collected_status) and not collected_status[tid]
            and (tid >= len(target_remaining_times) or target_remaining_times[tid] > 0) 
        ]
        self.all_assigned_targets_collected = not self.assigned_targets
        return self.all_assigned_targets_collected

    def start_collecting(self, target_id):
        if self.currently_collecting is None and target_id is not None:
             self.is_collecting = True
             self.currently_collecting = target_id

             
             if target_id >= len(target_current_collection_times):
                 
                 target_current_collection_times.extend([0] * (target_id - len(target_current_collection_times) + 1))

             target_current_collection_times[target_id] = 0
             print(f"DEBUG: Agent {self.id} reset collection time for target {target_id}.")

    def update_collection_progress(self):
        if not self.is_collecting or self.currently_collecting is None:
            return False, None 

        target_id = self.currently_collecting

        
        if target_id < 0 or \
           target_id >= len(target_current_collection_times) or \
           target_id >= len(collected) or \
           target_id >= len(target_remaining_times) or \
           collected[target_id] or \
           (target_remaining_times[target_id] <= 0 and not (self.is_collecting and self.currently_collecting == target_id)):
             print(f"Warning: Agent {self.id} attempting to update collection for target ID {target_id} which is invalid, already collected, or expired. Resetting collection state.")
             self.is_collecting = False
             self.currently_collecting = None
             
             if target_id in self.assigned_targets:
                  self.assigned_targets.remove(target_id)
                  print(f"DEBUG: Agent {self.id} removed invalid target {target_id} from assigned list during collection update.")
             return False, None 

        target_current_collection_times[target_id] += 1

        if target_current_collection_times[target_id] >= target_collection_times[target_id]:
            completed_target_id = self.currently_collecting
            self.is_collecting = False
            self.currently_collecting = None

            
            if completed_target_id is not None and completed_target_id in self.assigned_targets:
                self.assigned_targets.remove(completed_target_id)
                print(f"DEBUG: Agent {self.id} removed collected target {completed_target_id} from assigned list.")

            return True, completed_target_id 
        return False, None 


def export_agent_simulation_summary(robots_list, filename="agent_simulation_summary.csv"):
    """
    Exports agent statistics (targets collected, iterations moved) to a CSV file.
    """
    if not robots_list: # Added a check for empty list
        print("WARNING: The 'robots' list is empty. No agent summary data to export.")
        return

    fieldnames = ['AgentName', 'AgentID', 'TotalTargetsCollected', 'TotalDistanceTraveled_Iterations']

    try:
        with open(filename, mode='w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for agent in robots_list:
                try:
                    writer.writerow({
                        'AgentName': agent.name,
                        'AgentID': agent.id,
                        'TotalTargetsCollected': len(agent.collected_targets),
                        'TotalDistanceTraveled_Iterations': agent.iterations_moved
                    })
                except AttributeError as e:
                    print(f"ERROR: Could not write data for agent {getattr(agent, 'name', 'Unknown')}. Missing attribute: {e}")
        print(f"INFO: Agent simulation summary successfully saved to {filename}")
    except IOError:
        print(f"ERROR: Could not write to file {filename}. Check permissions or path.")
    except Exception as e:
        print(f"ERROR: An unexpected error occurred while exporting agent summary: {e}")


def compute_mission_reward(agent, old_pos, moved, next_assigned_target_pos, unassigned_targets_pos, action, is_collecting_completed):
    reward = 0

    if is_collecting_completed:
        reward += 20.0 
    if agent.is_collecting and action != -1:
        reward -= 5.0 

    if not moved and action != -1:
        reward -= 1.0 

    if next_assigned_target_pos and agent.grid_pos == next_assigned_target_pos:
         if not is_collecting_completed:
              reward += 10.0


    elif moved: 
        reward -= 0.01 


    return reward

def check_rl_convergence(episode_rewards_history, window_size, reward_threshold, all_agents_reached_target_in_last_episode_flag, phase_name="RL"):
    if not episode_rewards_history: 
        return False
    if len(episode_rewards_history) < window_size * 2:
        
        
        return False

    recent_rewards = np.array(episode_rewards_history[-window_size:])
    previous_rewards = np.array(episode_rewards_history[-window_size*2:-window_size])

    avg_recent = np.mean(recent_rewards)
    avg_previous = np.mean(previous_rewards)

    reward_improvement = avg_recent - avg_previous

    if reward_improvement < reward_threshold:
        if all_agents_reached_target_in_last_episode_flag:
            print(f"INFO: {phase_name} Convergence DETECTED. Avg Reward Last {window_size} episodes: {avg_recent:.2f}, Avg Reward Previous {window_size} episodes: {avg_previous:.2f}. Improvement: {reward_improvement:.2f} < Threshold: {reward_threshold}. All agents reached targets in the last episode.")
            return True
        else:
            print(f"DEBUG: {phase_name} - Reward converged (Improvement: {reward_improvement:.2f} vs threshold {reward_threshold}), but not all agents reached targets in the last episode. Continuing training.")
            return False
    else:
        
        return False

def trigger_global_rl_relearning_phase(reason=""):
    print(f"\n=== TRIGGERING GLOBAL RL RELEARNING PHASE for ALL Agents ({reason}) ===")
    
    
    agent_positions_before_relearning = [r.grid_pos for r in robots]

    print("DEBUG: Resetting all Q-tables for global relearning.")
    for r_agent_loop in robots: 
        r_agent_loop.Q_table = np.zeros((GRID_SIZE, GRID_SIZE, GRID_SIZE, GRID_SIZE, len(ACTIONS)))

    relearn_episode_rewards_history = [] 

    for relearn_episode in range(RELEARNING_EPISODES):
        
        for i_agent, r_agent_loop in enumerate(robots):
            r_agent_loop.grid_pos = agent_positions_before_relearning[i_agent]
            r_agent_loop.reset_stuck_status()

        current_episode_total_reward_for_relearn = 0
        all_agents_reached_target_this_relearn_episode = {r_agent_loop.id: False for r_agent_loop in robots}

        decay_rate_relearn = (EPSILON_RELEARN_START - EPSILON_RELEARN_END) / (RELEARNING_EPISODES - 1) if RELEARNING_EPISODES > 1 else 0
        current_epsilon_for_relearn = max(EPSILON_RELEARN_END, EPSILON_RELEARN_START - decay_rate_relearn * relearn_episode)

        if (relearn_episode + 1) % 100 == 0 or relearn_episode == 0:
            print(f" Global Relearning ({reason}) Episode {relearn_episode + 1}/{RELEARNING_EPISODES}, Epsilon: {current_epsilon_for_relearn:.4f}")

        for relearn_iteration in range(RELEARNING_ITERATIONS_PER_EPISODE):
            
            current_simulated_positions_in_iteration = [r_agent_loop.grid_pos for r_agent_loop in robots]

            for r_agent_loop in robots:
                if all_agents_reached_target_this_relearn_episode[r_agent_loop.id]:
                    continue

                old_sim_pos = r_agent_loop.grid_pos
                
                
                
                relearn_target_pos = None
                if r_agent_loop.assigned_targets:
                    assigned_target_id = r_agent_loop.assigned_targets[0]
                    if assigned_target_id < len(targets) and \
                       not collected[assigned_target_id] and \
                       (assigned_target_id >= len(target_remaining_times) or target_remaining_times[assigned_target_id] > 0):
                        relearn_target_pos = targets[assigned_target_id]
                    else: 
                        print(f"DEBUG: Agent {r_agent_loop.id}'s first target {assigned_target_id} invalid during {reason} relearning. Checking next.")
                        if len(r_agent_loop.assigned_targets) > 0: r_agent_loop.assigned_targets.pop(0) 
                        if r_agent_loop.assigned_targets: 
                            assigned_target_id = r_agent_loop.assigned_targets[0]
                            if assigned_target_id < len(targets) and not collected[assigned_target_id] and \
                               (assigned_target_id >= len(target_remaining_times) or target_remaining_times[assigned_target_id] > 0):
                                relearn_target_pos = targets[assigned_target_id]
                            else: 
                                all_agents_reached_target_this_relearn_episode[r_agent_loop.id] = True
                                continue
                        else: 
                            all_agents_reached_target_this_relearn_episode[r_agent_loop.id] = True
                            continue
                
                if relearn_target_pos is None: 
                    all_agents_reached_target_this_relearn_episode[r_agent_loop.id] = True
                    continue

                
                occupied_for_step = [
                    pos for i_pos, pos in enumerate(current_simulated_positions_in_iteration) if i_pos != robots.index(r_agent_loop)
                ] + list(OBSTACLES) + [
                    targets[tid] for tid in range(len(targets))
                    if not collected[tid] and \
                       (tid >= len(task_allocation) or task_allocation[tid] != r_agent_loop.id) and \
                       targets[tid] not in OBSTACLES
                ]

                action = r_agent_loop.choose_action(current_epsilon_for_relearn, relearn_target_pos)
                potential_next_pos = r_agent_loop.get_next_position(action)
                moved = False
                if r_agent_loop.is_move_valid(potential_next_pos, occupied_for_step):
                    if action != -1: 
                        r_agent_loop.grid_pos = potential_next_pos 
                        moved = True
                
                reward = compute_mission_reward(r_agent_loop, old_sim_pos, moved, relearn_target_pos, None, action, False)
                current_episode_total_reward_for_relearn += reward
                
                if action != -1 and relearn_target_pos is not None:
                    r_agent_loop.update_q_value(old_sim_pos, action, reward, r_agent_loop.grid_pos, relearn_target_pos)

                if r_agent_loop.grid_pos == relearn_target_pos:
                    all_agents_reached_target_this_relearn_episode[r_agent_loop.id] = True
            
            if all(all_agents_reached_target_this_relearn_episode.values()):
                break 

        relearn_episode_rewards_history.append(current_episode_total_reward_for_relearn)
        if check_rl_convergence(relearn_episode_rewards_history,
                                 RL_CONVERGENCE_WINDOW_SIZE_RETRAIN,
                                 RL_CONVERGENCE_THRESHOLD_RETRAIN,
                                 all(all_agents_reached_target_this_relearn_episode.values()),
                                 phase_name=f"GLOBAL RELEARNING ({reason})"):
            print(f"=== GLOBAL RELEARNING ({reason}) CONVERGED after {relearn_episode + 1} episodes. ===")
            break
    
    print(f"=== GLOBAL RL LEARNING PHASE COMPLETE ({reason}) ===")
    
    for i_agent, r_agent_loop in enumerate(robots):
        r_agent_loop.grid_pos = agent_positions_before_relearning[i_agent]
        r_agent_loop.set_webots_position(r_agent_loop.grid_pos)
    print(f"DEBUG: Agents' Webots positions restored after global relearning ({reason}).")


class PSO:
    def __init__(self, num_agents, num_targets_initial_sim, num_particles, agents, all_targets, collected_status, all_target_remaining_times, all_target_collection_times):
        self.num_agents = num_agents
        self.num_particles = num_particles
        self.agents = agents
        self.all_targets = all_targets
        self.collected_status = collected_status
        self.all_target_remaining_times = all_target_remaining_times
        self.all_target_collection_times = all_target_collection_times
        self.fitness_history = []
        self.save_fitness_history = []
        self.raw_fitness_components_log = []
        practical_max_feasible_targets = float(num_targets_initial_sim)

        self.norm_ranges = {
            'sum_time_overruns': {'min': 0.0, 'max': 20.0}, 
            'workload_difference': {'min': 0.0, 'max': 5.0}, 
            'workload_variance': {'min': 0.0, 'max': 15.0},
            'idle_agents_factor': {'min': 0.0, 'max': 0.5 if self.num_agents == 2 else 1.0}, 
            'sum_workload_deviations': {'min': 0.0, 'max': 10.0}, 
            'time_difference_steps': {'min': 0.0, 'max': 20.0}, 
            'time_variance_steps': {'min': 0.0, 'max': 50.0},
            'sum_time_deviations': {'min': 0.0, 'max': 30.0},   
            'maintaining_collection_bonus_applied': {'min': 0.0, 'max': float(self.num_agents)}, 
            'targets_missed': {'min': 0.0, 'max': practical_max_feasible_targets},
            'total_system_travel': {'min': 0.0, 'max': float(self.num_agents * practical_max_feasible_targets * GRID_SIZE)} 
        }
        for comp_name_key, r_dict in self.norm_ranges.items():
            if r_dict['max'] <= r_dict['min']:
                print(f"Warning: Normalization range for '{comp_name_key}' has max ({r_dict['max']}) <= min ({r_dict['min']}). Adjusting max. Please set a realistic max if this component can vary.")
                r_dict['max'] = r_dict['min'] + (1.0 if r_dict['min'] == 0 and r_dict['max'] == 0 else abs(r_dict['min'] * 0.1) + 1.0)
                if r_dict['max'] <= r_dict['min']: 
                    r_dict['max'] = r_dict['min'] + 1.0


        self._update_feasible_targets()
        print(f"DEBUG: PSO initialized. Considering {self.num_feasible_targets} feasible targets initially.")

        self.particles = []
        self.velocities = []
        self.personal_best_positions = []
        self.personal_best_fitness = []
        self.global_best_position_feasible_indices = []
        self.global_best_position = np.full(len(self.all_targets), -1)
        self.global_best_fitness = float('inf')

        self.c1 = C1
        self.c2 = C2
        self.inertia_weight = INERTIA_WEIGHT_START

        if self.num_feasible_targets > 0:
            self.initialize_particles()
        else:
            print("DEBUG: No feasible targets to initialize PSO particles.")
            self.global_best_fitness, _ = self._calculate_fitness_value([], particle_idx_log=-1, pso_iter_log=-1)

    def _update_feasible_targets(self):
        self.feasible_target_indices = [
            i for i in range(len(self.all_targets))
            if not self.collected_status[i] and
               (i >= len(self.all_target_remaining_times) or self.all_target_remaining_times[i] > 0) and
               is_target_feasible(i, self.agents, self.all_targets, self.all_target_remaining_times, self.all_target_collection_times)
        ]
        self.num_feasible_targets = len(self.feasible_target_indices)

    def _normalize_component(self, value, component_name):
        if component_name not in self.norm_ranges:
            print(f"Warning: Normalization range not defined for component {component_name}")
            return float(value)
        min_val = self.norm_ranges[component_name]['min']
        max_val = self.norm_ranges[component_name]['max']
        if max_val == min_val:
            return 0.0
        normalized = (float(value) - min_val) / (max_val - min_val)
        return max(0.0, min(1.0, normalized))

    def initialize_particles(self):
        if self.num_feasible_targets <= 0:
            return
        self.particles = [self.random_allocation(self.num_feasible_targets) for _ in range(self.num_particles)]
        self.velocities = [np.zeros(self.num_feasible_targets) for _ in range(self.num_particles)]
        self.personal_best_positions = [list(p) for p in self.particles]
        self.personal_best_fitness = []
        for i_particle, p_feasible_list in enumerate(self.particles):
            fitness_val, _ = self._calculate_fitness_value(p_feasible_list, particle_idx_log=i_particle, pso_iter_log=0)
            self.personal_best_fitness.append(fitness_val)
        if self.personal_best_fitness:
            best_idx = np.argmin(self.personal_best_fitness)
            self.global_best_position_feasible_indices = list(self.personal_best_positions[best_idx])
            self.global_best_fitness = self.personal_best_fitness[best_idx]
        else:
            self.global_best_position_feasible_indices = []
            self.global_best_fitness = float('inf')
        print(f"DEBUG: PSO Particles Initialized. Global Best Fitness: {self.global_best_fitness:.2f}")
        self._map_feasible_gb_to_full_gb()

    def _map_feasible_gb_to_full_gb(self):
        self.global_best_position = np.full(len(self.all_targets), -1)
        for i, feasible_idx_orig in enumerate(self.feasible_target_indices):
            if i < len(self.global_best_position_feasible_indices):
                self.global_best_position[feasible_idx_orig] = self.global_best_position_feasible_indices[i]

    def random_allocation(self, num_targets_to_allocate):
        if self.num_agents <= 0: return []
        return [random.randint(0, self.num_agents - 1) for _ in range(num_targets_to_allocate)]

    def _calculate_fitness_value(self, particle_feasible_indices_list, particle_idx_log=None, pso_iter_log=None):
        current_particle_components = {}
        if pso_iter_log is not None: current_particle_components['pso_iteration'] = pso_iter_log
        if particle_idx_log is not None: current_particle_components['particle_id_in_batch'] = particle_idx_log

        if self.num_feasible_targets == 0:
            raw_targets_missed = sum(1 for i_cs, cs in enumerate(self.collected_status) if not cs and (i_cs >= len(self.all_target_remaining_times) or self.all_target_remaining_times[i_cs] > 0))
            for comp_name_key in self.norm_ranges.keys(): current_particle_components[comp_name_key] = 0.0
            current_particle_components['targets_missed'] = float(raw_targets_missed)
            norm_targets_missed = self._normalize_component(float(raw_targets_missed), 'targets_missed')
            W_TARGETS_MISSED_DEFAULT = 1000.0
            missed_target_penalty_final = norm_targets_missed * W_TARGETS_MISSED_DEFAULT
            penalty_keys = ['time_penalty_final', 'workload_diff_penalty_final', 'workload_var_penalty_final',
                            'idle_penalty_final', 'workload_dev_penalty_final', 'time_diff_penalty_final',
                            'time_var_penalty_final', 'time_dev_penalty_final', 'maintaining_collection_bonus_final']
            for key in penalty_keys: current_particle_components[key] = 0.0
            current_particle_components['missed_target_penalty_final'] = missed_target_penalty_final
            current_particle_components['total_fitness'] = missed_target_penalty_final
            if particle_idx_log is not None or pso_iter_log is not None:
                 self.raw_fitness_components_log.append(current_particle_components)
            return missed_target_penalty_final, current_particle_components
        raw_sum_time_overruns = 0.0; raw_workload_difference = 0.0; raw_workload_variance = 0.0;
        raw_idle_agents_factor = 0.0; raw_sum_workload_deviations = 0.0; raw_time_difference_steps = 0.0;
        raw_time_variance_steps = 0.0; raw_sum_time_deviations = 0.0; raw_maintaining_collection_bonus_count = 0;
        raw_targets_missed = 0.0; targets_collected_in_this_allocation = 0
        agent_assigned_feasible_target_ids = [[] for _ in range(self.num_agents)]

        for i_idx_in_particle, agent_id_val in enumerate(particle_feasible_indices_list):
            original_target_id = self.feasible_target_indices[i_idx_in_particle]
            if 0 <= agent_id_val < self.num_agents:
                agent_assigned_feasible_target_ids[agent_id_val].append(original_target_id)

        agent_projected_completion_times_steps = [0.0] * self.num_agents
        agent_total_travel_distances = [0.0] * self.num_agents 

        for agent_idx, agent_obj in enumerate(self.agents):
            assigned_ids_for_agent = agent_assigned_feasible_target_ids[agent_idx]

            ordered_ids, est_time, travel_dist = get_nearest_neighbor_order(
                agent_obj.grid_pos, assigned_ids_for_agent, self.all_targets,
                self.all_target_remaining_times, self.all_target_collection_times
            )
            agent_projected_completion_times_steps[agent_idx] = float(est_time)
            agent_total_travel_distances[agent_idx] = float(travel_dist) 

            time_elapsed = 0.0
            current_pos = agent_obj.grid_pos
            for target_id in ordered_ids:
                travel = float(estimate_travel_time(current_pos, self.all_targets[target_id]))
                collection = float(self.all_target_collection_times[target_id])
                task_completion_time = time_elapsed + travel + collection
                deadline = float(self.all_target_remaining_times[target_id])
                if task_completion_time > deadline and not (agent_obj.is_collecting and agent_obj.currently_collecting == target_id):
                    raw_sum_time_overruns += (task_completion_time - deadline)
                else:
                    targets_collected_in_this_allocation += 1
                time_elapsed += (travel + collection)
                current_pos = self.all_targets[target_id]

        agent_workload = [float(len(ids)) for ids in agent_assigned_feasible_target_ids]
        active_workloads = [w for w in agent_workload if w > 0]
        if active_workloads:
            raw_workload_difference = max(agent_workload) - min(active_workloads)
            raw_workload_variance = np.var(active_workloads) if len(active_workloads) > 1 else 0.0
        else: 
            raw_workload_difference = 0.0
            raw_workload_variance = 0.0


        idle_agents = sum(1 for w in agent_workload if w == 0)
        working_agents = self.num_agents - idle_agents
        if idle_agents > 0 and working_agents > 0 and self.num_feasible_targets > 0:
            raw_idle_agents_factor = float(idle_agents * (working_agents / self.num_agents))

        if self.num_agents > 0 and self.num_feasible_targets > 0:
            ideal_wl = float(self.num_feasible_targets) / self.num_agents
            raw_sum_workload_deviations = sum(abs(w - ideal_wl) for w in agent_workload)
        else:
            raw_sum_workload_deviations = 0.0


        active_times = [t for t in agent_projected_completion_times_steps if t > 0]
        if active_times:
            raw_time_difference_steps = max(agent_projected_completion_times_steps) - min(active_times)
            raw_time_variance_steps = np.var(active_times) if len(active_times) > 1 else 0.0
            if self.num_agents > 0:
                ideal_time = sum(agent_projected_completion_times_steps) / self.num_agents if self.num_agents >0 else 0
                raw_sum_time_deviations = sum(abs(t - ideal_time) for t in agent_projected_completion_times_steps)
            else:
                raw_sum_time_deviations = 0.0
        else:
            raw_time_difference_steps = 0.0
            raw_time_variance_steps = 0.0
            raw_sum_time_deviations = 0.0


        full_allocation_map = np.full(len(self.all_targets), -1)
        for i_f, orig_idx in enumerate(self.feasible_target_indices):
            if i_f < len(particle_feasible_indices_list):
                 full_allocation_map[orig_idx] = particle_feasible_indices_list[i_f]

        for orig_target_idx, assigned_agent_id in enumerate(full_allocation_map):
            if 0 <= assigned_agent_id < self.num_agents:
                agent_obj = self.agents[assigned_agent_id]
                if agent_obj.is_collecting and agent_obj.currently_collecting == orig_target_idx:
                    raw_maintaining_collection_bonus_count += 1

        raw_targets_missed = float(self.num_feasible_targets - targets_collected_in_this_allocation)
        if raw_targets_missed < 0: raw_targets_missed = 0.0

        current_particle_components.update({
            'sum_time_overruns': raw_sum_time_overruns, 'workload_difference': raw_workload_difference,
            'workload_variance': raw_workload_variance, 'idle_agents_factor': raw_idle_agents_factor,
            'sum_workload_deviations': raw_sum_workload_deviations, 'time_difference_steps': raw_time_difference_steps,
            'time_variance_steps': raw_time_variance_steps, 'sum_time_deviations': raw_sum_time_deviations,
            'maintaining_collection_bonus_applied': float(raw_maintaining_collection_bonus_count),
            'targets_missed': raw_targets_missed
        })

        norm_sum_time_overruns = self._normalize_component(raw_sum_time_overruns, 'sum_time_overruns')
        norm_workload_difference = self._normalize_component(raw_workload_difference, 'workload_difference')
        norm_workload_variance = self._normalize_component(raw_workload_variance, 'workload_variance')
        norm_idle_agents_factor = self._normalize_component(raw_idle_agents_factor, 'idle_agents_factor')
        norm_sum_workload_deviations = self._normalize_component(raw_sum_workload_deviations, 'sum_workload_deviations')
        norm_time_difference_steps = self._normalize_component(raw_time_difference_steps, 'time_difference_steps')
        norm_time_variance_steps = self._normalize_component(raw_time_variance_steps, 'time_variance_steps')
        norm_sum_time_deviations = self._normalize_component(raw_sum_time_deviations, 'sum_time_deviations')
        norm_maintaining_collection_bonus_applied_count = self._normalize_component(float(raw_maintaining_collection_bonus_count), 'maintaining_collection_bonus_applied')
        norm_targets_missed = self._normalize_component(raw_targets_missed, 'targets_missed')


        # These weights now act on values typically in the 0-1 range.
        W_TIME_OVERRUN = 500.0     # Higher if critical and normalized values are sensible
        W_WORKLOAD_DIFF = 0.0      # Keep disabled if variance is used
        W_WORKLOAD_VAR = 100.0     # Moderate importance for balancing
        W_IDLE_FACTOR = 100.0      # Make it more impactful if avoiding idle agents is key
        W_WORKLOAD_DEV = 0.0       # Keep disabled
        W_TIME_DIFF = 0.0          # Keep disabled
        W_TIME_VAR = 80.0          # Moderate importance for time balancing
        W_TIME_DEV = 0.0           # Keep disabled
        W_MAINTAIN_BONUS = 50.0    # Adjust based on how strongly you want to encourage this
        W_TARGETS_MISSED = 2000.0  # Remains very high, acts on normalized 0-1 value

        time_penalty_final = norm_sum_time_overruns * W_TIME_OVERRUN
        workload_diff_penalty_final = norm_workload_difference * W_WORKLOAD_DIFF
        workload_var_penalty_final = norm_workload_variance * W_WORKLOAD_VAR
        idle_penalty_final = norm_idle_agents_factor * W_IDLE_FACTOR
        workload_dev_penalty_final = norm_sum_workload_deviations * W_WORKLOAD_DEV
        time_diff_penalty_final = norm_time_difference_steps * W_TIME_DIFF
        time_var_penalty_final = norm_time_variance_steps * W_TIME_VAR
        time_dev_penalty_final = norm_sum_time_deviations * W_TIME_DEV
        actual_bonus_value = norm_maintaining_collection_bonus_applied_count * W_MAINTAIN_BONUS
        missed_target_penalty_final = norm_targets_missed * W_TARGETS_MISSED

        fitness_value = (time_penalty_final + workload_diff_penalty_final + workload_var_penalty_final +
                         idle_penalty_final + workload_dev_penalty_final + time_diff_penalty_final +
                         time_var_penalty_final + time_dev_penalty_final + missed_target_penalty_final -
                         actual_bonus_value) # Subtract the bonus

        current_particle_components.update({
            'time_penalty_final': time_penalty_final, 'workload_diff_penalty_final': workload_diff_penalty_final,
            'workload_var_penalty_final': workload_var_penalty_final, 'idle_penalty_final': idle_penalty_final,
            'workload_dev_penalty_final': workload_dev_penalty_final, 'time_diff_penalty_final': time_diff_penalty_final,
            'time_var_penalty_final': time_var_penalty_final, 'time_dev_penalty_final': time_dev_penalty_final,
            'missed_target_penalty_final': missed_target_penalty_final,
            'maintaining_collection_bonus_final': -actual_bonus_value, # Log as negative
            'total_fitness': fitness_value
        })
        if particle_idx_log is not None or pso_iter_log is not None:
            self.raw_fitness_components_log.append(current_particle_components)
        return fitness_value, current_particle_components

    def update_inertia_weight(self, iteration, max_iterations):
        if max_iterations <= 0:
             self.inertia_weight = INERTIA_WEIGHT_END
             return
        progress = float(iteration) / max_iterations
        self.inertia_weight = INERTIA_WEIGHT_START - progress * (INERTIA_WEIGHT_START - INERTIA_WEIGHT_END)
        self.inertia_weight = max(INERTIA_WEIGHT_END, self.inertia_weight)

    def step(self, all_targets_updated, collected_status_updated, all_target_remaining_times_updated, all_target_collection_times_updated, pso_iteration_num_for_log):
        self.all_targets = all_targets_updated
        self.collected_status = collected_status_updated
        self.all_target_remaining_times = all_target_remaining_times_updated
        self.all_target_collection_times = all_target_collection_times_updated

        previous_num_feasible_targets = self.num_feasible_targets
        self._update_feasible_targets()

        if self.num_feasible_targets != previous_num_feasible_targets or not self.particles:
            print(f"DEBUG: Feasible targets changed or PSO not initialized. Old: {previous_num_feasible_targets}, New: {self.num_feasible_targets}. Re-initializing particles.")
            if self.num_feasible_targets > 0:
                self.initialize_particles()
            else:
                self.particles = []; self.velocities = []; self.personal_best_positions = []; self.personal_best_fitness = []
                self.global_best_position_feasible_indices = []
                self.global_best_position = np.full(len(self.all_targets), -1)
                self.global_best_fitness, _ = self._calculate_fitness_value([], particle_idx_log=-2, pso_iter_log=pso_iteration_num_for_log)

        if self.num_feasible_targets == 0:
            if self.global_best_fitness == float('inf'):
                 self.global_best_fitness, _ = self._calculate_fitness_value([], particle_idx_log=-2, pso_iter_log=pso_iteration_num_for_log)
            self.save_fitness_history.append(self.global_best_fitness) 
            return np.full(len(self.all_targets), -1)

        for i in range(self.num_particles):
            particle_feasible_assignment_list = self.particles[i]
            for j in range(self.num_feasible_targets):
                inertia = self.inertia_weight * self.velocities[i][j]
                pb_j_val = self.personal_best_positions[i][j]
                cognitive = self.c1 * random.random() * (pb_j_val - particle_feasible_assignment_list[j])

                if j < len(self.global_best_position_feasible_indices):
                    gb_j_val = self.global_best_position_feasible_indices[j]
                else: 
                    gb_j_val = particle_feasible_assignment_list[j] 

                social = self.c2 * random.random() * (gb_j_val - particle_feasible_assignment_list[j])
                new_velocity = inertia + cognitive + social
                new_velocity = max(min(new_velocity, MAX_VELOCITY), -MAX_VELOCITY)
                self.velocities[i][j] = new_velocity
                new_pos_float = particle_feasible_assignment_list[j] + new_velocity
                new_agent_assignment = int(round(new_pos_float))
                new_agent_assignment = max(0, min(self.num_agents - 1, new_agent_assignment))
                self.particles[i][j] = new_agent_assignment
            
            current_fitness, _ = self._calculate_fitness_value(self.particles[i], particle_idx_log=i, pso_iter_log=pso_iteration_num_for_log)

            if current_fitness < self.personal_best_fitness[i]:
                self.personal_best_fitness[i] = current_fitness
                self.personal_best_positions[i] = list(self.particles[i])

        current_best_particle_idx = np.argmin(self.personal_best_fitness)
        if self.personal_best_fitness[current_best_particle_idx] < self.global_best_fitness:
            self.global_best_fitness = self.personal_best_fitness[current_best_particle_idx]
            self.global_best_position_feasible_indices = list(self.personal_best_positions[current_best_particle_idx])
            self._map_feasible_gb_to_full_gb()
        
        self.save_fitness_history.append(self.global_best_fitness)
        return self.global_best_position.copy()

    def save_raw_fitness_components_to_csv(self, filename="pso_raw_fitness_components.csv"):
        if not self.raw_fitness_components_log:
            print("DEBUG: No raw fitness components to save.")
            return
        
        header = []
        if self.raw_fitness_components_log:
            sample_keys = self.raw_fitness_components_log[0].keys()
            desired_header_order = [
                'pso_iteration', 'particle_id_in_batch',
                'sum_time_overruns', 'workload_difference', 'workload_variance',
                'idle_agents_factor', 'sum_workload_deviations', 'time_difference_steps',
                'time_variance_steps', 'sum_time_deviations',
                'maintaining_collection_bonus_applied', 'targets_missed',
                'time_penalty_final', 'workload_diff_penalty_final', 'workload_var_penalty_final',
                'idle_penalty_final', 'workload_dev_penalty_final', 'time_diff_penalty_final',
                'time_var_penalty_final', 'time_dev_penalty_final', 'missed_target_penalty_final',
                'maintaining_collection_bonus_final', 'total_fitness'
            ]
            header = [h for h in desired_header_order if h in sample_keys]
            header.extend(sorted([k for k in sample_keys if k not in desired_header_order]))

        with open(filename, mode='w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=header, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(self.raw_fitness_components_log)
        print(f"DEBUG: PSO raw fitness component data saved to {filename}")

    def save_fitness_to_csv(self, filename):
        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['PSO_Iteration', 'Global_Best_Fitness'])
            for i, fitness in enumerate(self.save_fitness_history):
                writer.writerow([i + 1, fitness])
        print(f"DEBUG: PSO global best fitness history saved to {filename}")
from controller import Supervisor
supervisor = Supervisor()
timestep = int(supervisor.getBasicTimeStep())
iteration_count = supervisor.getTime() 


initial_targets_pos =[(4, 6), (4, 7), (4, 8), (4, 9), (4, 10), (4, 11), (4, 12), (4, 13), (4, 14), (4, 15), (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11), (5, 12), (5, 13), (5, 14), (5, 15), (8, 15), (9, 15), (10, 15), (11, 15), (12, 15), (13, 15), (14, 15), (15, 15), (8, 14), (9, 14), (10, 14), (11, 14), (12, 14), (13, 14), (14, 14), (15, 14), (8, 11), (9, 11), (10, 11), (11, 11), (12, 11), (13, 11), (14, 11), (15, 11), (8, 10), (9, 10), (10, 10), (11, 10), (12, 10), (13, 10), (14, 10), (15, 10)]
targets = list(initial_targets_pos)
collected = [False] * len(targets)
collected_by = [None] * len(targets)

target_collection_times = [random.randint(MIN_COLLECTION_TIME, MAX_COLLECTION_TIME) for _ in range(len(targets))]

target_remaining_times = []
target_current_collection_times = [0] * len(targets)
for i in range(len(targets)):
    if (5 <= i <= 9) or (15 <= i <= 19) or (20 <= i <= 23) or (28 <= i <= 31) or (36 <= i <= 39) or (44 <= i <= 47) :
        target_remaining_times.append(int(P1_REMAINING_TIME))
    elif (0 <= i <= 4) or (24 <= i <= 27) or (32 <= i <= 35):
        target_remaining_times.append(int(P2_REMAINING_TIME))
    else:
        target_remaining_times.append(int(P3_REMAINING_TIME))

prev_collected_status = list(collected)
prev_target_remaining_times = list(target_remaining_times)


print("DEBUG: Initial Target Remaining Times:", target_remaining_times)


robots = [Agent(name, i) for i, name in enumerate(AGENT_NAMES)]


pretrain_episode_numbers = []
pretrain_cumulative_rewards = []
pretrain_steps_per_episode = []
pretrain_epsilon_values = []
pretrain_episode_rewards_list = [] 


print("=== INITIALIZING AND RUNNING PSO FOR TASK ALLOCATION ===")
pso = PSO(NUM_AGENTS, NUM_TARGETS, NUM_PARTICLES, robots, targets, collected, target_remaining_times, target_collection_times)
task_allocation = []
if pso.num_feasible_targets > 0:
    for iteration in range(PSO_ITERATIONS_INITIAL):
        pso.update_inertia_weight(iteration, PSO_ITERATIONS_INITIAL)
        task_allocation = pso.step(targets, collected, target_remaining_times, target_collection_times, pso_iteration_num_for_log=iteration)
else:
    
    task_allocation = np.full(len(targets), -1)

pso.save_fitness_to_csv("initial_pso_fitness.csv")
pso.save_raw_fitness_components_to_csv("initial_pso_raw_components.csv") 
pso.raw_fitness_components_log = [] 
print("=== ASSIGNING INITIAL TASKS BASED ON PSO ALLOCATION ===")
for agent_id, agent in enumerate(robots):
    currently_collecting_target_id = agent.currently_collecting if agent.is_collecting and agent.currently_collecting is not None else None

    agent.assigned_targets.clear() 
    agent.all_assigned_targets_collected = False

    other_assigned_feasible_target_ids = []
    num_current_targets = len(targets)
    current_task_allocation = list(task_allocation) 
    for tid in range(num_current_targets):
        if current_task_allocation[tid] == agent_id and not collected[tid] and (tid >= len(target_remaining_times) or target_remaining_times[tid] > 0 or (agent.is_collecting and agent.currently_collecting == tid)):
            if tid != currently_collecting_target_id: 
                 other_assigned_feasible_target_ids.append(tid)


    ordered_other_assigned_target_ids, _, _ = get_nearest_neighbor_order( 
        agent.grid_pos,
        other_assigned_feasible_target_ids,
        targets,
        target_remaining_times,
        target_collection_times,
    )

    final_assigned_targets = []
    
    if currently_collecting_target_id is not None and currently_collecting_target_id < len(targets) and not collected[currently_collecting_target_id]:
        final_assigned_targets.append(currently_collecting_target_id)

    final_assigned_targets.extend(ordered_other_assigned_target_ids) 
    agent.assigned_targets = final_assigned_targets


print("\n=== INITIAL TARGET ASSIGNMENTS (Ordered by Time-Prioritized Nearest Neighbor, Prioritizing Current Collection) ===")
for agent_id, agent in enumerate(robots):
    assigned_target_indices = list(agent.assigned_targets)
    assigned_target_info = []
    for tid in assigned_target_indices:
        if tid < len(targets) and tid < len(target_collection_times) and tid < len(target_remaining_times):
             assigned_target_info.append((tid, targets[tid], f"CollectTime:{target_collection_times[tid]}", f"RemainingTime:{target_remaining_times[tid]:.2f}"))
        elif tid < len(targets): 
             assigned_target_info.append((tid, targets[tid], "CollectTime:N/A", "RemainingTime:N/A"))
        else: 
             assigned_target_info.append((tid, "N/A", "CollectTime:N/A", "RemainingTime:N/A"))


    print(f"DEBUG:   Agent {agent.id} assigned targets: {assigned_target_info})")



print("=== STARTING PRE-TRAINING (Episode-based RL Path Planning) ===")
print(f"Running {PRETRAINING_EPISODES} episodes, {PRETRAINING_ITERATIONS_PER_EPISODE} iterations per episode.")


for episode in range(PRETRAINING_EPISODES):
    
    for agent in robots:
        agent.set_webots_position(AGENT_START_POSITIONS[agent.id]) 
        agent.reset_stuck_status()

    
    episode_assigned_targets_per_agent = {}
    for agent_id, agent in enumerate(robots):
        if agent.assigned_targets: 
            first_assigned_target_id = agent.assigned_targets[0] 

            
            if first_assigned_target_id < len(targets) and \
               not collected[first_assigned_target_id] and \
               (first_assigned_target_id >= len(target_remaining_times) or target_remaining_times[first_assigned_target_id] > 0):
                 episode_assigned_targets_per_agent[agent_id] = targets[first_assigned_target_id]
            else:
                 
                 
                 
                 print(f"Warning: Agent {agent_id}'s first assigned target ID {first_assigned_target_id} is invalid or already processed. Considering next or fallback for pre-training episode {episode + 1}.")
                 
                 found_next_valid = False
                 for tid in agent.assigned_targets:
                     if tid < len(targets) and not collected[tid] and (tid >= len(target_remaining_times) or target_remaining_times[tid] > 0):
                         episode_assigned_targets_per_agent[agent_id] = targets[tid]
                         found_next_valid = True
                         break
                 if not found_next_valid:
                    episode_assigned_targets_per_agent[agent_id] = None 
        else:
            print(f"Warning: Agent {agent_id} has no PSO-assigned targets for pre-training episode {episode + 1}.")
            episode_assigned_targets_per_agent[agent_id] = None

    decay_rate = (EPSILON_PRETRAIN_START - EPSILON_PRETRAIN_END) / (PRETRAINING_EPISODES - 1) if PRETRAINING_EPISODES > 1 else 0
    current_epsilon = max(EPSILON_PRETRAIN_END, EPSILON_PRETRAIN_START - decay_rate * episode)

    episode_total_reward = 0
    episode_steps_count = 0
    
    
    agents_reached_target_in_episode = {agent_id: False for agent_id in range(NUM_AGENTS)}


    if (episode + 1) % 100 == 0 or episode == 0:
         print(f" Episode {episode + 1}/{PRETRAINING_EPISODES}, Epsilon: {current_epsilon:.4f}")


    for iteration in range(PRETRAINING_ITERATIONS_PER_EPISODE):
        episode_steps_count += 1

        
        
        simulated_occupied_positions_this_step = [agent.grid_pos for agent_id, agent in enumerate(robots) if not agents_reached_target_in_episode[agent_id]]

        current_iteration_reward_sum = 0

        for agent_id, agent in enumerate(robots):
            if agents_reached_target_in_episode[agent_id]:
                continue 

            target_pos_for_episode = episode_assigned_targets_per_agent.get(agent_id)
            if target_pos_for_episode is None: 
                continue

            old_pos = agent.grid_pos

            action = agent.choose_action(current_epsilon, target_pos_for_episode)
            potential_next_pos = agent.get_next_position(action)

            other_agents_simulated_positions = [
                r.grid_pos for r_idx, r in enumerate(robots) 
                if r_idx != agent_id and not agents_reached_target_in_episode[r_idx]
            ]

            
            simulated_occupied_for_agent = other_agents_simulated_positions + list(OBSTACLES)

            
            
            unassigned_target_positions_pretrain = [
                targets[tid] for tid in range(len(targets)) 
                
                
                
                if (tid >= len(task_allocation) or task_allocation[tid] != agent_id) and \
                   not collected[tid] and \
                   targets[tid] not in OBSTACLES
            ]
            simulated_occupied_for_agent.extend(unassigned_target_positions_pretrain)
            
            
            simulated_occupied_for_agent = list(set(simulated_occupied_for_agent))

            move_is_valid_simulated = agent.is_move_valid(potential_next_pos, simulated_occupied_for_agent)

            moved = False
            if action != -1 and move_is_valid_simulated:
                 agent.grid_pos = potential_next_pos
                 moved = True

            
            
            reward = compute_mission_reward(agent, old_pos, moved, target_pos_for_episode, None, action, False)
            current_iteration_reward_sum += reward

            if action != -1 and target_pos_for_episode is not None:
                 agent.update_q_value(old_pos, action, reward, agent.grid_pos, target_pos_for_episode)
           
            if agent.grid_pos == target_pos_for_episode:
                agents_reached_target_in_episode[agent_id] = True

        episode_total_reward += current_iteration_reward_sum

        if all(agents_reached_target_in_episode.values()):
            break

    pretrain_episode_numbers.append(episode)
    pretrain_cumulative_rewards.append(episode_total_reward)
    pretrain_steps_per_episode.append(episode_steps_count)
    pretrain_epsilon_values.append(current_epsilon)
    pretrain_episode_rewards_list.append(episode_total_reward) 
    
    all_agents_finished_pretrain_episode = all(agents_reached_target_in_episode.values())
    if check_rl_convergence(episode_rewards_history=pretrain_episode_rewards_list,
                             window_size=RL_CONVERGENCE_WINDOW_SIZE_PRETRAIN,
                             reward_threshold=RL_CONVERGENCE_THRESHOLD_PRETRAIN,
                             all_agents_reached_target_in_last_episode_flag=all_agents_finished_pretrain_episode,
                             phase_name="PRE-TRAINING"):
        print(f"=== PRE-TRAINING CONVERGED after {episode + 1} episodes. ===")
        
        break

    
    
    
    


print("=== PRE-TRAINING COMPLETE ===")
import csv
with open('rl_pretraining_progress.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['Episode', 'Cumulative_Reward', 'Steps_per_Episode', 'Epsilon'])
    
    for i in range(len(pretrain_episode_numbers)):
        writer.writerow([pretrain_episode_numbers[i], pretrain_cumulative_rewards[i], pretrain_steps_per_episode[i], pretrain_epsilon_values[i]])

print("DEBUG: RL pre-training progress saved to rl_pretraining_progress.csv")

print("=== End Initial Q-Tables ===")

print("\n=== STARTING MAIN SIMULATION ===")

for i in range(NUM_AGENTS):
    robots[i].set_webots_position(AGENT_START_POSITIONS[i])
    robots[i].reset_stuck_status()
    

spawn_boxes(initial_targets_pos, TARGET_BOXES_INITIAL)
if len(OBSTACLES) == len(OBSTACLE_NODES):
    spawn_boxes2(OBSTACLES, OBSTACLE_NODES)
    print("DEBUG: Spawned visual obstacles.")
else:
    print(f"WARNING: Number of obstacles ({len(OBSTACLES)}) does not match number of obstacle node names ({len(OBSTACLE_NODES)}). Skipping visual obstacle spawning.")


current_epsilon = EPSILON_EXECUTION
iteration_count = 0
final_total_mission_reward = 0

stuck_detection_interval = 20

initial_targets_collected_printed = False
dynamic_targets_collected_printed = False
all_targets_spawned = False 
total_targets_collected_count = 0


next_dynamic_spawn_time_index = 0 
next_dynamic_spawn_time_step = -1 

print("\n=== STARTING MAIN SIMULATION LOOP (Execution) ===")

prev_collected_status = list(collected)
prev_target_remaining_times = list(target_remaining_times)





def perform_agent_relearning(agent_obj, initial_agent_pos, all_targets_data, all_collected_status_data, all_target_remaining_times_data, all_target_collection_times_data):
    original_agent_pos = agent_obj.grid_pos 
    agent_obj.grid_pos = initial_agent_pos 
    agent_obj.Q_table = np.zeros((GRID_SIZE, GRID_SIZE, GRID_SIZE, GRID_SIZE, len(ACTIONS))) 
    agent_obj.reset_stuck_status() 

    print(f"\n=== STARTING POST-COLLECTION RL LEARNING PHASE for Agent {agent_obj.id} ===")
    print(f"Agent {agent_obj.id} starting relearning from {initial_agent_pos} with new Q-table.")

    for relearn_episode in range(RELEARNING_EPISODES): 
        agent_obj.grid_pos = initial_agent_pos
        agent_obj.reset_stuck_status()

        if not agent_obj.assigned_targets:
            print(f"Agent {agent_obj.id} has no more assigned targets for relearning.")
            break

        assigned_target_id = agent_obj.assigned_targets[0]
        assigned_target_pos = all_targets_data[assigned_target_id]

        decay_rate_relearn = (EPSILON_RELEARN_START - EPSILON_RELEARN_END) / (RELEARNING_EPISODES - 1) if RELEARNING_EPISODES > 1 else 0
        current_epsilon_relearn = max(EPSILON_RELEARN_END, EPSILON_RELEARN_START - decay_rate_relearn * relearn_episode)

        if (relearn_episode + 1) % 100 == 0 or relearn_episode == 0:
            print(f" Relearning Episode {relearn_episode + 1}/{RELEARNING_EPISODES}, Epsilon: {current_epsilon_relearn:.4f}")

        

        for relearn_iteration in range(RELEARNING_ITERATIONS_PER_EPISODE):
            old_pos = agent_obj.grid_pos

            
            
            simulated_occupied_but_self = [
                r.grid_pos for r in robots if r.id != agent_obj.id
            ] + list(OBSTACLES) + [
                targets[tid] for tid in range(len(targets))
                if not collected[tid] and
                task_allocation[tid] != agent_obj.id and 
                targets[tid] not in OBSTACLES
            ]

            action = agent_obj.choose_action(current_epsilon_relearn, assigned_target_pos)
            potential_next_pos = agent_obj.get_next_position(action)

            move_is_valid_simulated = agent_obj.is_move_valid(potential_next_pos, simulated_occupied_but_self)

            moved = False
            if action != -1 and move_is_valid_simulated:
                agent_obj.grid_pos = potential_next_pos 
                moved = True

            
            reward = compute_mission_reward(agent_obj, old_pos, moved, assigned_target_pos, None, action, False)
            

            
            if action != -1 and assigned_target_pos is not None:
                 agent_obj.update_q_value(old_pos, action, reward, agent_obj.grid_pos, assigned_target_pos)

            if assigned_target_pos is not None and agent_obj.grid_pos == assigned_target_pos:
                print(f"DEBUG: Agent {agent_obj.id} reached its relearning target {assigned_target_pos} in episode {relearn_episode + 1}, iteration {relearn_iteration + 1}.")
                break 

    print(f"=== POST-COLLECTION RL LEARNING PHASE COMPLETE for Agent {agent_obj.id} ===")
    agent_obj.grid_pos = original_agent_pos 
    agent_obj.set_webots_position(agent_obj.grid_pos) 
    print(f"DEBUG: Agent {agent_obj.id} position reset to {agent_obj.grid_pos} after relearning and Webots updated.")
    
while supervisor.step(timestep) != -1:
    current_step_mission_reward = 0
    any_target_expired_this_step = False
    # --- ADDED FOR DEADLOCK ---
    relearning_triggered_in_step = False 
    # --- END ADDED FOR DEADLOCK ---
    
    targets_to_hide_on_expiry = []
    for i in range(len(targets)):
        if not collected[i] and not (any(agent.is_collecting and agent.currently_collecting == i for agent in robots)):
            if i < len(target_remaining_times):
                target_remaining_times[i] -= 1
                if target_remaining_times[i] <= 0 and not collected[i] and i not in expired_target_messages_printed:
                    any_target_expired_this_step = True 
                    target_remaining_times[i] = 0 
                    print(f"Target {i} at {targets[i]} EXPIRED at simulation time {iteration_count:.2f} iteration.")
                    targets_to_hide_on_expiry.append(i)
                    expired_target_messages_printed.add(i)

    for expired_target_id in targets_to_hide_on_expiry:
        box_name_to_hide = None
        if expired_target_id < NUM_TARGETS:
            box_name_to_hide = TARGET_BOXES_INITIAL[expired_target_id]
        elif expired_target_id >= NUM_TARGETS and (expired_target_id - NUM_TARGETS) < MAX_ADDITIONAL_TARGETS:
            try:
                spawn_order_index = expired_target_id - NUM_TARGETS
                if spawn_order_index < len(ADDITIONAL_BOXES):
                    box_name_to_hide = ADDITIONAL_BOXES[spawn_order_index]
                else:
                    print(f"Warning: Could not find box name for dynamic target ID {expired_target_id}. Spawn order index {spawn_order_index} out of bounds for ADDITIONAL_BOXES.")
            except Exception as e:
                print(f"Error mapping dynamic target {expired_target_id} to box name: {e}")
                box_name_to_hide = None
        if box_name_to_hide:
            hide_box(box_name_to_hide)
            
    if any_target_expired_this_step: 
        print("INFO: Target expiry detected. Updating assignments and task allocation state for relearning.")
        for r_update_agent in robots: 
            r_update_agent.update_assigned_targets_collected_status(collected)
        for tid_check in range(len(task_allocation)):
            if tid_check < len(targets) and \
               (collected[tid_check] or \
                (tid_check < len(target_remaining_times) and target_remaining_times[tid_check] <= 0 and not any(agent.is_collecting and agent.currently_collecting == tid_check for agent in robots))): 
                if task_allocation[tid_check] != -1:
                    task_allocation[tid_check] = -1 
        trigger_global_rl_relearning_phase(reason="Target Expiry")
        # --- ADDED FOR DEADLOCK (Robustness: Reset counters after ANY global relearn) ---
        for r_reset in robots:
            r_reset.last_attempted_blocked_cell_by_agent = None
            r_reset.consecutive_attempts_on_same_blocked_cell = 0
        # --- END ADDED FOR DEADLOCK ---
        
    if next_dynamic_spawn_time_index < MAX_ADDITIONAL_TARGETS:
        if next_dynamic_spawn_time_step == -1:
            random_interval_steps = random.randint(DYNAMIC_SPAWN_INTERVAL_MIN_STEPS, DYNAMIC_SPAWN_INTERVAL_MAX_STEPS)
            next_dynamic_spawn_time_step = iteration_count + random_interval_steps
            print(f"DEBUG: First dynamic target scheduled to spawn around simulation step {next_dynamic_spawn_time_step} (in ~{random_interval_steps} steps).")
        if iteration_count >= next_dynamic_spawn_time_step:
              dynamic_target_index_to_spawn = dynamic_targets_spawned_count
              print(f"\n=== Spawning Dynamic Target {dynamic_target_index_to_spawn + NUM_TARGETS} at simulation step {iteration_count} ===")

              new_target_pos = None
              if dynamic_target_index_to_spawn < len(PREDEFINED_DYNAMIC_TARGET_POSITIONS):
                  potential_pos = PREDEFINED_DYNAMIC_TARGET_POSITIONS[dynamic_target_index_to_spawn]
                  
                  all_taken_positions = set(OBSTACLES)
                  all_taken_positions.update(targets) 
                  all_taken_positions.update([r.grid_pos for r in robots]) 
            
                  if potential_pos is not None and potential_pos not in all_taken_positions and is_valid_grid_position(potential_pos):
                      new_target_pos = potential_pos
                  else:
                      print(f"Warning: Predefined dynamic target position {potential_pos} is invalid or already occupied. Skipping spawn.")
              else:
                  print(f"Warning: No predefined dynamic target position available for index {dynamic_target_index_to_spawn}. Skipping spawn.")
            
              if new_target_pos is None:
                  print(f"Warning: Could not find a valid spawn position for dynamic target.") 
                  
                  
                  next_dynamic_spawn_time_index += 1
                  if dynamic_targets_spawned_count < MAX_ADDITIONAL_TARGETS:
                     random_interval_steps = random.randint(DYNAMIC_SPAWN_INTERVAL_MIN_STEPS, DYNAMIC_SPAWN_INTERVAL_MAX_STEPS)
                     next_dynamic_spawn_time_step = iteration_count + random_interval_steps
                     print(f"DEBUG: Next dynamic target scheduled to spawn around simulation step {next_dynamic_spawn_time_step} (in ~{random_interval_steps} steps).")
                  else:
                     next_dynamic_spawn_time_step = float('inf') 
                  
                  all_targets_spawned = (dynamic_targets_spawned_count == MAX_ADDITIONAL_TARGETS) 
                  continue 


              new_target_global_index = len(targets)

              targets.append(new_target_pos)
              collected.append(False)
              collected_by.append(None)
              collection_time = random.randint(MIN_COLLECTION_TIME, MAX_COLLECTION_TIME)
              target_collection_times.append(collection_time)
              if dynamic_target_index_to_spawn < len(DYNAMIC_TARGET_EXPIRY_TIMES_SECONDS):
                    remaining_time_steps = int(DYNAMIC_TARGET_EXPIRY_TIMES_SECONDS[dynamic_target_index_to_spawn] * 1000.0 / timestep)
                    target_remaining_times.append(remaining_time_steps)
              else:
                    default_expiry_seconds = 10.0
                    default_expiry_steps = int(default_expiry_seconds * 1000.0 / timestep)
                    target_remaining_times.append(default_expiry_steps)
                    print(f"Warning: DYNAMIC_TARGET_EXPIRY_TIMES_SECONDS list is shorter than MAX_ADDITIONAL_TARGETS. Using default expiry time for dynamic target {dynamic_target_index_to_spawn}.")

              target_current_collection_times.append(0)

              prev_collected_status = list(collected)
              prev_target_remaining_times = list(target_remaining_times)


              if dynamic_target_index_to_spawn < len(ADDITIONAL_BOXES):
                   box_name_to_spawn = ADDITIONAL_BOXES[dynamic_target_index_to_spawn]
                   spawn_boxes([new_target_pos], [box_name_to_spawn])
                   print(f"New target {box_name_to_spawn} spawned at {new_target_pos} (Target ID: {new_target_global_index}, Collection Time: {collection_time}, Remaining Time: {target_remaining_times[new_target_global_index]:.2f})")
              else:
                  print(f"Warning: Not enough dynamic box names configured for target ID {new_target_global_index}")


              dynamic_targets_spawned_count += 1
              print(" Reallocating tasks due to new dynamic target...")
              pso = PSO(NUM_AGENTS, len(targets), NUM_PARTICLES, robots, targets, collected, target_remaining_times, target_collection_times)

              task_allocation = np.full(len(targets), -1) 
              if pso.num_feasible_targets > 0:
                  for pso_iter in range(PSO_ITERATIONS_REALLOC):
                       pso.update_inertia_weight(pso_iter, PSO_ITERATIONS_REALLOC)
                       task_allocation = pso.step(targets, collected, target_remaining_times, target_collection_times, pso_iteration_num_for_log=pso_iter)
              else:
                   print("DEBUG: No feasible targets after spawning dynamic target. Task allocation is all unassigned.")
                   task_allocation = np.full(len(targets), -1)


              for agent_id, agent in enumerate(robots):
                  currently_collecting_target_id = agent.currently_collecting if agent.is_collecting and agent.currently_collecting is not None else None
                  agent.assigned_targets.clear()
                  agent.all_assigned_targets_collected = False

                  other_assigned_feasible_target_ids = []
                  num_current_targets = len(targets)
                  current_task_allocation = list(task_allocation)
                  for tid in range(num_current_targets):
                      if current_task_allocation[tid] == agent_id and not collected[tid] and (tid >= len(target_remaining_times) or target_remaining_times[tid] > 0 or (agent.is_collecting and agent.currently_collecting == tid)):
                          if tid != currently_collecting_target_id:
                              other_assigned_feasible_target_ids.append(tid)


                  ordered_other_assigned_target_ids, _, _ = get_nearest_neighbor_order( 
                        agent.grid_pos,
                        other_assigned_feasible_target_ids,
                        targets,
                        target_remaining_times,
                        target_collection_times,
                    )
                

                  final_assigned_targets = []
                  if currently_collecting_target_id is not None and currently_collecting_target_id < len(targets) and not collected[currently_collecting_target_id]:
                      final_assigned_targets.append(currently_collecting_target_id)

                  final_assigned_targets.extend(ordered_other_assigned_target_ids)
                  agent.assigned_targets = final_assigned_targets


              print("DEBUG: Task reassignment completed.")

              print(f"DEBUG: Assignments after reallocation at iteration {iteration_count} (Ordered by Time-Prioritized Nearest Neighbor):")
              for agent_id, agent in enumerate(robots):
                   assigned_target_indices = list(agent.assigned_targets)
                   assigned_target_info = []
                   for tid in assigned_target_indices:
                       if tid < len(targets) and tid < len(target_collection_times) and tid < len(target_remaining_times):
                           assigned_target_info.append((tid, targets[tid], f"CollectTime:{target_collection_times[tid]}", f"RemainingTime:{target_remaining_times[tid]:.2f}"))
                       elif tid < len(targets):
                            assigned_target_info.append((tid, targets[tid], "CollectTime:N/A", "RemainingTime:N/A"))
                       else:
                           assigned_target_info.append((tid, "N/A", "CollectTime:N/A", "RemainingTime:N/A"))


                   print(f"DEBUG:   Agent {agent.id} assigned targets: {assigned_target_info})")
              print("DEBUG: Resetting all agents' Q-tables for dynamic target relearning.")
              for agent in robots:
                  agent.Q_table = np.zeros((GRID_SIZE, GRID_SIZE, GRID_SIZE, GRID_SIZE, len(ACTIONS)))

              agent_positions_before_relearning = [(agent.grid_pos) for agent in robots]
              print(f"\n=== STARTING NEW RL LEARNING PHASE (Dynamic Targets) for ALL Agents ===")
              dynamic_target_relearn_episode_rewards_history = []

              
              

              for relearn_episode in range(RELEARNING_EPISODES):
                  
                  for i, agent in enumerate(robots):
                      agent.grid_pos = agent_positions_before_relearning[i]
                      agent.reset_stuck_status()
                      
                  relearn_episode_total_reward = 0 
                  all_agents_reached_target_this_episode = {agent.id: False for agent in robots} 
                  decay_rate_relearn = (EPSILON_RELEARN_START - EPSILON_RELEARN_END) / (RELEARNING_EPISODES - 1) if RELEARNING_EPISODES > 1 else 0
                  current_epsilon_relearn = max(EPSILON_RELEARN_END, EPSILON_RELEARN_START - decay_rate_relearn * relearn_episode)

                  if (relearn_episode + 1) % 100 == 0 or relearn_episode == 0:
                       print(f" Relearning Episode {relearn_episode + 1}/{RELEARNING_EPISODES}, Epsilon: {current_epsilon_relearn:.4f}")

                  relearn_episode_total_reward = 0 

                  all_agents_reached_target_this_episode = {agent.id: False for agent in robots}

                  for relearn_iteration in range(RELEARNING_ITERATIONS_PER_EPISODE):
                      
                      simulated_occupied_positions_this_step_relearn = [agent.grid_pos for agent in robots]
                      
                      for agent_id, agent in enumerate(robots):
                          if all_agents_reached_target_this_episode[agent_id]:
                              continue

                          old_pos = agent.grid_pos

                          assigned_target_pos_for_relearn = None
                          if agent.assigned_targets:
                              assigned_target_id_for_relearn = agent.assigned_targets[0]
                              if assigned_target_id_for_relearn < len(targets) and \
                                 not collected[assigned_target_id_for_relearn] and \
                                 (assigned_target_id_for_relearn >= len(target_remaining_times) or target_remaining_times[assigned_target_id_for_relearn] > 0):
                                  assigned_target_pos_for_relearn = targets[assigned_target_id_for_relearn]
                              else:
                                  agent.assigned_targets.pop(0)
                                  assigned_target_pos_for_relearn = None
                                  if not agent.assigned_targets:
                                      all_agents_reached_target_this_episode[agent_id] = True
                                      continue

                          action = agent.choose_action(current_epsilon_relearn, assigned_target_pos_for_relearn)
                          potential_next_pos = agent.get_next_position(action)

                          simulated_occupied_but_self = [pos for i, pos in enumerate(simulated_occupied_positions_this_step_relearn) if i != agent_id] + list(OBSTACLES)
                          simulated_occupied_but_self.extend([targets[tid] for tid in range(len(targets)) if task_allocation[tid] != agent_id and not collected[tid] and targets[tid] not in OBSTACLES])
                          move_is_valid_simulated = agent.is_move_valid(potential_next_pos, simulated_occupied_but_self)

                          moved = False
                          if action != -1 and move_is_valid_simulated:
                               agent.grid_pos = potential_next_pos
                               moved = True

                          
                          
                          reward = compute_mission_reward(agent, old_pos, moved, assigned_target_pos_for_relearn, None, action, False)
                          relearn_episode_total_reward += reward

                          if action != -1 and assigned_target_pos_for_relearn is not None:
                               agent.update_q_value(old_pos, action, reward, agent.grid_pos, assigned_target_pos_for_relearn)

                          if assigned_target_pos_for_relearn is not None and agent.grid_pos == assigned_target_pos_for_relearn:
                              all_agents_reached_target_this_episode[agent_id] = True
                   
                      if all(all_agents_reached_target_this_episode.values()):
                          break

                  

                  dynamic_target_relearn_episode_rewards_history.append(relearn_episode_total_reward)
                  all_agents_finished_dynamic_relearn_episode = all(all_agents_reached_target_this_episode.values())

                  if check_rl_convergence(episode_rewards_history=dynamic_target_relearn_episode_rewards_history,
                                           window_size=RL_CONVERGENCE_WINDOW_SIZE_RETRAIN,
                                           reward_threshold=RL_CONVERGENCE_THRESHOLD_RETRAIN,
                                           all_agents_reached_target_in_last_episode_flag=all_agents_finished_dynamic_relearn_episode,
                                           phase_name="DYNAMIC TARGET RELEARNING"):
                      print(f"=== DYNAMIC TARGET RELEARNING CONVERGED after {relearn_episode + 1} episodes. ===")
                      break
               
              print(f"=== NEW RL LEARNING PHASE COMPLETE ===")
              
              for i, agent in enumerate(robots):
                     agent.grid_pos = agent_positions_before_relearning[i]
                     agent.set_webots_position(agent.grid_pos)
              print("DEBUG: Agents positions reset to before relearning and Webots updated.")
              print("DEBUG: Resetting all agents' deadlock counters after dynamic target relearning (if any occurred).")
              for r_reset in robots:
                r_reset.last_attempted_blocked_cell_by_agent = None
                r_reset.consecutive_attempts_on_same_blocked_cell = 0
            # --- END ADDED FOR DEADLOCK ---

            # Your original logic for setting up the next spawn:
              next_dynamic_spawn_time_index += 1
              if dynamic_targets_spawned_count < MAX_ADDITIONAL_TARGETS:
                random_interval_steps = random.randint(DYNAMIC_SPAWN_INTERVAL_MIN_STEPS, DYNAMIC_SPAWN_INTERVAL_MAX_STEPS)
                next_dynamic_spawn_time_step = iteration_count + random_interval_steps
                print(f"DEBUG: Next dynamic target scheduled to spawn around simulation step {next_dynamic_spawn_time_step} (in ~{random_interval_steps} steps).")
              else:
                next_dynamic_spawn_time_step = float('inf') 
    
    all_targets_spawned = (dynamic_targets_spawned_count == MAX_ADDITIONAL_TARGETS) # Original line

    if iteration_count % stuck_detection_interval == 0: 
        stuck_agents = [] 
        for agent in robots: 
            if not agent.is_collecting and not agent.all_assigned_targets_collected and agent.update_stuck_status(): 
                stuck_agents.append(agent.id) 

    current_occupied_positions = [r.grid_pos for r in robots] # Original line

    for agent_id, agent in enumerate(robots):
        # --- ADDED FOR DEADLOCK ---
        if relearning_triggered_in_step:
            agent.last_attempted_blocked_cell_by_agent = None
            agent.consecutive_attempts_on_same_blocked_cell = 0
            continue
        # --- END ADDED FOR DEADLOCK ---

        completed, collected_target_id = agent.update_collection_progress()
        if completed:
            if collected_target_id is not None and collected_target_id < len(collected):
                collected[collected_target_id] = True
                collected_by[collected_target_id] = agent_id
                agent.collected_targets.append(collected_target_id)
                total_targets_collected_count += 1
                collection_time_completed = target_collection_times[collected_target_id] if collected_target_id < len(target_collection_times) else "N/A"
                target_pos_collected = targets[collected_target_id] if collected_target_id < len(targets) else "N/A"
                print(f"Target {collected_target_id} at {target_pos_collected} COLLECTED by Agent {agent_id} after {collection_time_completed} time steps at simulation time {iteration_count:.2f} iterations.")
                
                box_name_to_hide = None
                if collected_target_id < NUM_TARGETS:
                    box_name_to_hide = TARGET_BOXES_INITIAL[collected_target_id]
                elif collected_target_id >= NUM_TARGETS and (collected_target_id - NUM_TARGETS) < MAX_ADDITIONAL_TARGETS:
                    try:
                        spawn_order_index = collected_target_id - NUM_TARGETS
                        if spawn_order_index < len(ADDITIONAL_BOXES):
                            box_name_to_hide = ADDITIONAL_BOXES[spawn_order_index]
                        else:
                            print(f"Warning: Could not find box name for dynamic target ID {collected_target_id}. Spawn order index {spawn_order_index} out of bounds for ADDITIONAL_BOXES.")
                    except Exception as e:
                        print(f"Error mapping dynamic target {collected_target_id} to box name: {e}")
                        box_name_to_hide = None
                if box_name_to_hide:
                    hide_box(box_name_to_hide)
                
                collection_completion_reward = compute_mission_reward(agent, agent.grid_pos, False, None, None, -1, True)
                current_step_mission_reward += collection_completion_reward
                final_total_mission_reward += collection_completion_reward
                
                print("INFO: Target collection detected. Updating all agent assignments and task allocation before relearning.")
                for r_update_agent in robots: 
                    r_update_agent.update_assigned_targets_collected_status(collected)
                if collected_target_id is not None and collected_target_id < len(task_allocation):
                    if task_allocation[collected_target_id] != -1:
                        task_allocation[collected_target_id] = -1 
                
                trigger_global_rl_relearning_phase(reason="Post-Collection")
                # --- ADDED FOR DEADLOCK ---
                relearning_triggered_in_step = True 
                for r_reset in robots: 
                    r_reset.last_attempted_blocked_cell_by_agent = None
                    r_reset.consecutive_attempts_on_same_blocked_cell = 0
                # --- END ADDED FOR DEADLOCK ---
            # Your original file had two 'continue' statements here, which is redundant. One is enough.
            continue 

        if agent.is_collecting: 
            # --- ADDED FOR DEADLOCK ---
            agent.last_attempted_blocked_cell_by_agent = None
            agent.consecutive_attempts_on_same_blocked_cell = 0
            # --- END ADDED FOR DEADLOCK ---
            continue

        agent.update_assigned_targets_collected_status(collected)
        if agent.all_assigned_targets_collected: 
            # --- ADDED FOR DEADLOCK ---
            agent.last_attempted_blocked_cell_by_agent = None
            agent.consecutive_attempts_on_same_blocked_cell = 0
            # --- END ADDED FOR DEADLOCK ---
            continue

        next_assigned_target_id = agent.assigned_targets[0] if agent.assigned_targets else None
        next_assigned_target_pos = None
        if next_assigned_target_id is not None and next_assigned_target_id < len(targets):
            next_assigned_target_pos = targets[next_assigned_target_id]
        else: 
            print(f"Warning: Agent {agent.id} assigned_targets list contains invalid ID {next_assigned_target_id}. Clearing list.")
            agent.assigned_targets.clear()
            agent.all_assigned_targets_collected = True
            # --- ADDED FOR DEADLOCK ---
            agent.last_attempted_blocked_cell_by_agent = None
            agent.consecutive_attempts_on_same_blocked_cell = 0
            # --- END ADDED FOR DEADLOCK ---
            continue
            
        if agent.grid_pos == next_assigned_target_pos:
            # --- ADDED FOR DEADLOCK ---
            agent.last_attempted_blocked_cell_by_agent = None
            agent.consecutive_attempts_on_same_blocked_cell = 0
            # --- END ADDED FOR DEADLOCK ---
            target_id_to_collect = agent.assigned_targets[0] 
            if target_id_to_collect is not None and \
               target_id_to_collect < len(targets) and \
               targets[target_id_to_collect] == agent.grid_pos and \
               not collected[target_id_to_collect] and \
               (target_id_to_collect >= len(target_remaining_times) or target_remaining_times[target_id_to_collect] > 0):
                if not agent.is_collecting:
                    print(f"DEBUG: Agent {agent.id} reached target {target_id_to_collect} at {targets[target_id_to_collect]}. Starting collection.")
                    print(f"PRE-COLLECT CHECK: Agent {agent.id}, Target {target_id_to_collect}. collected[{target_id_to_collect}]={collected[target_id_to_collect]}, remaining_time={target_remaining_times[target_id_to_collect] if target_id_to_collect < len(target_remaining_times) else 'N/A'}")
                    agent.start_collecting(target_id_to_collect)
            else:
                print(f"DEBUG: Agent {agent.id} arrived at position of target {target_id_to_collect}, but it is no longer valid for collection. Removing from assigned list.")
                if agent.assigned_targets and agent.assigned_targets[0] == target_id_to_collect:
                    agent.assigned_targets.pop(0) 
                    agent.update_assigned_targets_collected_status(collected) 
            # Original reward calculation for being at target (implicitly handled as no move)
            # If agent is at target, it's effectively action -1 (stay) for reward purposes this turn if it just arrived or is collecting
            reward_at_target = compute_mission_reward(agent, agent.grid_pos, False, next_assigned_target_pos, None, -1, False)
            current_step_mission_reward += reward_at_target
            final_total_mission_reward += reward_at_target
            continue 

        old_pos = agent.grid_pos
        epsilon_for_step = EPSILON_EXECUTION 
        action = agent.choose_action(epsilon_for_step, next_assigned_target_pos)

        # --- MODIFIED FOR DEADLOCK (handling action == -1 before move attempt) ---
        if action == -1: # Agent chose not to move
            agent.last_attempted_blocked_cell_by_agent = None 
            agent.consecutive_attempts_on_same_blocked_cell = 0
            moved = False # Explicitly
        else: # Agent attempts a move
            potential_next_pos = agent.get_next_position(action)
            is_blocked_by_another_agent = False
            blocking_agent_id = -1
            for r_other in robots:
                if r_other.id != agent.id and r_other.grid_pos == potential_next_pos:
                    is_blocked_by_another_agent = True
                    blocking_agent_id = r_other.id
                    break
            
            current_agent_occupied_positions = [r.grid_pos for r in robots if r.id != agent_id] + list(OBSTACLES)
            current_agent_occupied_positions.extend([
                targets[tid] for tid in range(len(targets)) 
                if not collected[tid] and
                (tid >= len(task_allocation) or task_allocation[tid] != agent_id) and 
                targets[tid] not in OBSTACLES
            ])
            current_agent_occupied_positions = list(set(current_agent_occupied_positions)) # Ensure unique

            moved = agent.move(action, current_agent_occupied_positions, simulate_move_only=False) # Use current_agent_occupied_positions
            
            if not moved: 
                if is_blocked_by_another_agent:
                    if agent.last_attempted_blocked_cell_by_agent == potential_next_pos:
                        agent.consecutive_attempts_on_same_blocked_cell += 1
                    else:
                        agent.last_attempted_blocked_cell_by_agent = potential_next_pos
                        agent.consecutive_attempts_on_same_blocked_cell = 1
                    
                    print(f"DEBUG: Agent {agent.id} (at {agent.grid_pos}) ATTEMPT {agent.consecutive_attempts_on_same_blocked_cell}/{DEADLOCK_ATTEMPT_THRESHOLD} to move to {potential_next_pos} (blocked by Agent {blocking_agent_id} at {robots[blocking_agent_id].grid_pos}).")

                    if agent.consecutive_attempts_on_same_blocked_cell >= DEADLOCK_ATTEMPT_THRESHOLD:
                        print(f"!!! DEADLOCK DETECTED: Agent {agent.id} (at {agent.grid_pos}) vs Agent {blocking_agent_id} (at {robots[blocking_agent_id].grid_pos}) over cell {potential_next_pos}. Triggering relearning.")
                        trigger_global_rl_relearning_phase(reason=f"Agent Deadlock (A{agent.id}->{potential_next_pos} vs A{blocking_agent_id})")
                        relearning_triggered_in_step = True 
                        for r_reset in robots: 
                            r_reset.last_attempted_blocked_cell_by_agent = None
                            r_reset.consecutive_attempts_on_same_blocked_cell = 0
                else: 
                    agent.last_attempted_blocked_cell_by_agent = None 
                    agent.consecutive_attempts_on_same_blocked_cell = 0
            else: # Moved successfully
                agent.last_attempted_blocked_cell_by_agent = None 
                agent.consecutive_attempts_on_same_blocked_cell = 0
        # --- END MODIFIED FOR DEADLOCK ---
                
        reward = compute_mission_reward(agent, old_pos, moved, next_assigned_target_pos, None, action, False) 
        current_step_mission_reward += reward
        final_total_mission_reward += reward
            
        if moved:
            agent.reset_stuck_status() 

        # Your original proactive check if agent moved and landed on target
        # (This logic was slightly adjusted to avoid the 'break' from agent loop)
        if moved and not agent.is_collecting and agent.assigned_targets: 
            target_id_to_check = agent.assigned_targets[0] 
            if target_id_to_check < len(targets) and not collected[target_id_to_check] and \
               (target_id_to_check >= len(target_remaining_times) or target_remaining_times[target_id_to_check] > 0) and \
               agent.grid_pos == targets[target_id_to_check]:
                print(f"DEBUG: Agent {agent.id} at {agent.grid_pos} detected uncollected assigned target {target_id_to_check} after move. Attempting to start collection.")
                print(f"PRE-COLLECT CHECK (Proactive): Agent {agent.id}, Target {target_id_to_check}. collected[{target_id_to_check}]={collected[target_id_to_check]}, remaining_time={target_remaining_times[target_id_to_check] if target_id_to_check < len(target_remaining_times) else 'N/A'}")
                # Ensure target is still valid before starting collection again
                if not collected[target_id_to_check] and \
                   (target_id_to_check >= len(target_remaining_times) or target_remaining_times[target_id_to_check] > 0):
                    agent.start_collecting(target_id_to_check)
                else:
                    print(f"DEBUG: Agent {agent.id} found target {target_id_to_check} (proactive check) invalid. Removing.")
                    if agent.assigned_targets and agent.assigned_targets[0] == target_id_to_check:
                        agent.assigned_targets.pop(0)
                    agent.update_assigned_targets_collected_status(collected)
                # Removed original 'break' here to allow other agents to process in the same timestep.

    iteration_count += 1
    delay_seconds = 0.01
    time.sleep(delay_seconds)
    
    all_currently_spawned_targets_processed = all(
        collected[i] or 
        (i < len(target_remaining_times) and target_remaining_times[i] <= 0 and not any(agent.is_collecting and agent.currently_collecting == i for agent in robots)) 
        for i in range(len(targets))
    )

    if all_currently_spawned_targets_processed and all_targets_spawned:
        print(f"\n=== Simulation Complete ===")
        print(f"=== Simulation ended at iteration {iteration_count} at simulation time {supervisor.getTime():.2f} seconds. ===")
        print(f"=== Total Targets Initially: {NUM_TARGETS}. Total Dynamic Targets Spawned: {dynamic_targets_spawned_count}. Total Targets in Simulation: {len(targets)}. ===")
        print(f"=== Total Targets Collected: {total_targets_collected_count}. ===")
        expired_count = sum(1 for i in range(len(targets)) if (i < len(target_remaining_times) and target_remaining_times[i] <= 0) and not collected[i])
        print(f"=== Total Targets Expired: {expired_count}. ===")
        print(f"=== Final Total Mission Reward: {final_total_mission_reward:.2f} ===")

        print("\n=== FINAL TARGET COLLECTION SUMMARY ===")
        agent_actual_collection_times = [0] * NUM_AGENTS
        for agent_idx_summary, agent_summary_obj in enumerate(robots): 
            collected_target_ids = sorted(agent_summary_obj.collected_targets)
            print(f"Agent {agent_summary_obj.id} collected targets (IDs): {collected_target_ids}")
            actual_time_collecting = sum(target_collection_times[tid] for tid in collected_target_ids if tid < len(target_collection_times))
            print(f" Agent {agent_summary_obj.id} total *actual time* spent collecting: {actual_time_collecting} simulation steps")
            agent_actual_collection_times[agent_idx_summary] = actual_time_collecting

        print("\n=== FINAL COLLECTION TIME FAIRNESS ANALYSIS (Actual Time Spent) ===")
        print(f"Agent actual time spent collecting: {agent_actual_collection_times}")
        break 

if not (all_currently_spawned_targets_processed and all_targets_spawned):
    print(f"\nSimulation ended manually at step {iteration_count} at simulation time {supervisor.getTime():.2f} seconds.")
    print(f"Total Targets Initially: {NUM_TARGETS}. Total Dynamic Targets Spawned: {dynamic_targets_spawned_count}. Total Targets in Simulation: {len(targets)}. ===") # Note: Original had "===" at the end here.
    print(f"Total Targets Collected: {total_targets_collected_count}.")
    # Ensure expired_count is defined if this block is reached
    expired_count_at_manual_end = sum(1 for i in range(len(targets)) if (i < len(target_remaining_times) and target_remaining_times[i] <= 0) and not collected[i])
    print(f"Expired targets: {expired_count_at_manual_end}.")
    uncollected_and_not_expired_at_manual_end = sum(1 for i in range(len(targets)) if not collected[i] and (i < len(target_remaining_times) and target_remaining_times[i] > 0))
    print(f"Uncollected and not expired targets remaining: {uncollected_and_not_expired_at_manual_end}.")

print(f"Simulation done after {iteration_count:.2f} iterations.")
print("Simulation finished.")
print("INFO: Exporting agent simulation summary...")
export_agent_simulation_summary(robots)