import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def plot_global_best_fitness_progression(df_main, fitness_csv_filepath=None):
    plt.figure(figsize=(10, 5))
    iterations_data_available = False

    if fitness_csv_filepath:
        try:
            df_fitness = pd.read_csv(fitness_csv_filepath)
            if 'Iteration' in df_fitness.columns and 'total_fitness' in df_fitness.columns:
                sns.lineplot(x='Iteration', y='Fitness', data=df_fitness, marker='o', label='Global Best Fitness')
                plt.title('Global Best Total Fitness vs. PSO Iteration (from Fitness History CSV)')
                iterations_data_available = True
            else:
                print(f"Warning: Columns 'Iteration' or 'Fitness' not found in '{fitness_csv_filepath}'.")
        except FileNotFoundError:
            print(f"Warning: Fitness history CSV '{fitness_csv_filepath}' not found.")
        except Exception as e:
            print(f"Error reading fitness history CSV '{fitness_csv_filepath}': {e}")

    if not iterations_data_available and 'pso_iteration' in df_main.columns and 'total_fitness' in df_main.columns:
        if df_main['pso_iteration'].isna().all():
            print("Warning: 'pso_iteration' column in main CSV has no valid data for global best fitness plot.")
        else:
            
            
            df_main['pso_iteration'] = pd.to_numeric(df_main['pso_iteration'], errors='coerce')
            df_main_cleaned = df_main.dropna(subset=['pso_iteration', 'total_fitness'])
            if not df_main_cleaned.empty:
                global_best_per_iteration = df_main_cleaned.loc[df_main_cleaned.groupby('pso_iteration')['total_fitness'].idxmin()]
                if not global_best_per_iteration.empty:
                    sns.lineplot(x='pso_iteration', y='total_fitness', data=global_best_per_iteration, marker='o', label='Global Best Fitness (derived)')
                    plt.title('Global Best Total Fitness vs. PSO Iteration (derived from main CSV)')
                    iterations_data_available = True
                else:
                    print("Warning: Could not derive global best fitness per iteration from main CSV.")
            else:
                print("Warning: No valid data in main CSV for pso_iteration or total_fitness to derive global best plot.")


    if iterations_data_available:
        plt.xlabel('PSO Iteration')
        plt.ylabel('Total Fitness')
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.show()
    else:
        plt.close() 
        print("Skipping Global Best Total Fitness progression plot as no suitable data was found.")


def plot_components_progression(df, components, title_prefix, pso_iteration_col='pso_iteration'):
    if pso_iteration_col not in df.columns:
        print(f"Warning: '{pso_iteration_col}' column not found. Skipping progression plots for components.")
        return
    if df[pso_iteration_col].isna().all():
        print(f"Warning: '{pso_iteration_col}' column has no valid data. Skipping progression plots.")
        return

    
    df[pso_iteration_col] = pd.to_numeric(df[pso_iteration_col], errors='coerce')
    df_cleaned = df.dropna(subset=[pso_iteration_col])


    existing_components = [col for col in components if col in df_cleaned.columns]
    if not existing_components:
        print(f"No components from the list found in the DataFrame for {title_prefix} progression.")
        return

    num_components = len(existing_components)
    if num_components == 0:
        return

    cols = 2
    rows = (num_components + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 6, rows * 4), squeeze=False)
    axes = axes.flatten()

    for i, component in enumerate(existing_components):
        ax = axes[i]
        
        try:
            
            numeric_component_data = pd.to_numeric(df_cleaned[component], errors='coerce')
            mean_per_iteration = numeric_component_data.groupby(df_cleaned[pso_iteration_col]).mean()
            if not mean_per_iteration.empty:
                 sns.lineplot(x=mean_per_iteration.index, y=mean_per_iteration.values, ax=ax, marker='.')
                 ax.set_title(f'Mean {component}', fontsize=9)
                 ax.set_xlabel('PSO Iteration', fontsize=8)
                 ax.set_ylabel('Mean Value', fontsize=8)
                 ax.tick_params(labelsize=7)
                 ax.grid(True)
            else:
                ax.text(0.5, 0.5, 'No data to plot', ha='center', va='center', fontsize=8)
                ax.set_title(f'Mean {component}', fontsize=9)
        except Exception as e:
            ax.text(0.5, 0.5, f'Error plotting:\n{e}', ha='center', va='center', fontsize=8, color='red')
            ax.set_title(f'Mean {component}', fontsize=9)


    for j in range(num_components, len(axes)):
        fig.delaxes(axes[j])

    fig.suptitle(f'{title_prefix} Progression Over PSO Iterations (Mean Values)', fontsize=12)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95]) 
    plt.show()


def plot_stacked_mean_weighted_contribution_progression(df, weighted_components, pso_iteration_col='pso_iteration'):
    if pso_iteration_col not in df.columns:
        print(f"Warning: '{pso_iteration_col}' column not found. Skipping stacked contribution plot.")
        return
    if df[pso_iteration_col].isna().all():
        print(f"Warning: '{pso_iteration_col}' column has no valid data. Skipping stacked contribution plot.")
        return

    df[pso_iteration_col] = pd.to_numeric(df[pso_iteration_col], errors='coerce')
    df_cleaned = df.dropna(subset=[pso_iteration_col])

    existing_weighted_components = [col for col in weighted_components if col in df_cleaned.columns]
    if not existing_weighted_components:
        print("No weighted components found for stacked contribution plot.")
        return

    
    iteration_groups = df_cleaned.groupby(pso_iteration_col)
    mean_contributions_over_iterations = pd.DataFrame()

    for component in existing_weighted_components:
        try:
            numeric_component_data = pd.to_numeric(df_cleaned[component], errors='coerce')
            mean_contributions_over_iterations[component] = numeric_component_data.groupby(df_cleaned[pso_iteration_col]).mean()
        except Exception as e:
            print(f"Could not process component {component} for stacked plot: {e}")
            continue 

    if mean_contributions_over_iterations.empty:
        print("No data to create stacked area plot.")
        return
        
    mean_contributions_over_iterations = mean_contributions_over_iterations.fillna(0) 

    if mean_contributions_over_iterations.empty:
        print("No valid mean contributions data to plot for stacked area chart.")
        return

    plt.figure(figsize=(12, 7))
    try:
        
        
        sns.color_palette("viridis", len(existing_weighted_components))
        plt.stackplot(mean_contributions_over_iterations.index,
                      [mean_contributions_over_iterations[col] for col in existing_weighted_components],
                      labels=existing_weighted_components,
                      alpha=0.8)

        plt.title('Mean Contribution of Weighted Components Over PSO Iterations (Stacked Area)', fontsize=12)
        plt.xlabel('PSO Iteration', fontsize=10)
        plt.ylabel('Mean Contribution to Total Fitness', fontsize=10)
        plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize=8)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.tight_layout(rect=[0, 0, 0.85, 1]) 
    except Exception as e:
        print(f"Error during stackplot generation: {e}")
        plt.text(0.5, 0.5, f"Error generating stackplot:\n{e}", horizontalalignment='center', verticalalignment='center', transform=plt.gca().transAxes, color='red')


    plt.show()


def analyze_pso_fitness_components(csv_filepath, pso_fitness_history_csv_filepath=None):
    cleaned_csv_filepath = csv_filepath.strip('"\'')
    try:
        df = pd.read_csv(cleaned_csv_filepath)
    except FileNotFoundError:
        print(f"Error: The file '{cleaned_csv_filepath}' was not found.")
        return
    except Exception as e:
        print(f"Error reading CSV file '{cleaned_csv_filepath}': {e}")
        return

    print(f"Successfully loaded {cleaned_csv_filepath}")
    
    
    if 'pso_iteration' not in df.columns:
        print("\nCRITICAL WARNING: The CSV file does not contain a 'pso_iteration' column.")
        print("Progression plots over iterations (for mean/median of all particles) cannot be generated without this column.")
        print("Please ensure your PSO logging saves the iteration number for each particle evaluation into this CSV.")
    elif df['pso_iteration'].isnull().all() or not pd.api.types.is_numeric_dtype(pd.to_numeric(df['pso_iteration'], errors='coerce')):
        print("\nCRITICAL WARNING: The 'pso_iteration' column is present but contains all NaNs, non-numeric data, or could not be reliably converted to numeric.")
        print("Progression plots over iterations (for mean/median of all particles) may be incorrect or fail.")
        print("Please ensure 'pso_iteration' is correctly populated with numeric iteration numbers.")


    raw_components = [
        'sum_time_overruns', 'workload_difference', 'workload_variance',
        'idle_agents_factor', 'sum_workload_deviations', 'time_difference_steps',
        'time_variance_steps', 'sum_time_deviations',
        'maintaining_collection_bonus_applied', 'targets_missed'
    ]
    final_weighted_components = [
        'time_penalty_final', 'workload_diff_penalty_final', 'workload_var_penalty_final',
        'idle_penalty_final', 'workload_dev_penalty_final', 'time_diff_penalty_final',
        'time_var_penalty_final', 'time_dev_penalty_final', 'missed_target_penalty_final',
        'maintaining_collection_bonus_final'
    ]
    existing_raw_components = [col for col in raw_components if col in df.columns]
    existing_final_weighted_components = [col for col in final_weighted_components if col in df.columns]

    if not existing_raw_components and not existing_final_weighted_components and 'total_fitness' not in df.columns :
        print("\nNo specified component columns or 'total_fitness' column found. Please check column names in the script and CSV.")
        return

    
    print("\n--- VISUALIZING PROGRESSION OVER PSO ITERATIONS ---")
    #plot_global_best_fitness_progression(df, pso_fitness_history_csv_filepath) 
    if 'pso_iteration' in df.columns and not df['pso_iteration'].isna().all():
        plot_components_progression(df, existing_raw_components, "Raw Component")
        plot_components_progression(df, existing_final_weighted_components, "Weighted Penalty")
        #plot_stacked_mean_weighted_contribution_progression(df, existing_final_weighted_components)
    else:
        print("\nSkipping mean/median progression plots due to missing or invalid 'pso_iteration' column in the main CSV.")


    
    print("\n--- VISUALIZING OVERALL DISTRIBUTIONS (from original script) ---")
    
    

    
    # if existing_raw_components:
    #     print("\nVisualizing RAW Fitness Components (Distributions):")
    #     num_components = len(existing_raw_components)
    #     if num_components > 0:
    #         cols = 3
    #         rows = (num_components + cols - 1) // cols
    #         fig, axes = plt.subplots(rows, cols,
    #                                  figsize=(cols * 4, rows * 3.5),
    #                                  squeeze=False)
    #         axes = axes.flatten()
    #         for i, component in enumerate(existing_raw_components):
    #             if i < len(axes):
    #                 ax = axes[i]
    #                 data_to_plot = df[component].replace([np.inf, -np.inf], np.nan).dropna()
    #                 if not data_to_plot.empty:
    #                     sns.histplot(data_to_plot, kde=True, ax=ax)
    #                     ax.set_title(f'{component}', fontsize=8)
    #                     ax.set_ylabel('Frequency', fontsize=7)
    #                     ax.tick_params(axis='x', labelsize=6, rotation=30)
    #                     ax.tick_params(axis='y', labelsize=6)
    #                 else:
    #                     ax.text(0.5, 0.5, 'No valid data', ha='center', va='center', fontsize=8)
    #                     ax.set_title(f'{component}', fontsize=8)
    #                     ax.set_xticks([])
    #                     ax.set_yticks([])
    #         for j in range(num_components, len(axes)):
    #             fig.delaxes(axes[j])
    #         fig.suptitle('Distributions of Raw PSO Fitness Components (Overall)', fontsize=12)
    #         fig.subplots_adjust(hspace=0.7, wspace=0.4, top=0.90, bottom=0.15)
    #         plt.show()

        # print("\nVisualizing RAW Fitness Components (Box Plots - Overall):")
        # fig_box, axes_box = plt.subplots(rows, cols,
        #                                  figsize=(cols * 3.5, rows * 3),
        #                                  squeeze=False)
        # axes_box = axes_box.flatten()
        # for i, component in enumerate(existing_raw_components):
        #     if i < len(axes_box):
        #         ax_b = axes_box[i]
        #         data_to_plot_box = df[component].replace([np.inf, -np.inf], np.nan).dropna()
        #         if not data_to_plot_box.empty:
        #             sns.boxplot(y=data_to_plot_box, ax=ax_b)
        #             ax_b.set_title(f'{component}', fontsize=8)
        #             ax_b.set_ylabel('Value', fontsize=7)
        #             ax_b.set_xticks([])
        #             ax_b.tick_params(axis='y', labelsize=6)
        #         else:
        #             ax_b.text(0.5, 0.5, 'No valid data', ha='center', va='center', fontsize=8)
        #             ax_b.set_title(f'{component}', fontsize=8)
        #             ax_b.set_xticks([])
        #             ax_b.set_yticks([])
        # for j in range(num_components, len(axes_box)):
        #     fig_box.delaxes(axes_box[j])
        # fig_box.suptitle('Box Plots of Raw PSO Fitness Components (Overall)', fontsize=12)
        # fig_box.subplots_adjust(hspace=0.6, wspace=0.4, top=0.90, bottom=0.1)
        # plt.show()

    
    # if existing_final_weighted_components:
    #     print("\nVisualizing FINAL Weighted Fitness Components (Mean Contributions - Overall):")
    #     if len(existing_final_weighted_components) > 0:
    #         mean_contributions = df[existing_final_weighted_components].mean().sort_values()
    #         plt.figure(figsize=(8, max(5, len(existing_final_weighted_components) * 0.4)))
    #         mean_contributions.plot(kind='barh')
    #         plt.title('Mean Contribution of Weighted Components (Overall)', fontsize=10)
    #         plt.xlabel('Mean Weighted Value', fontsize=8)
    #         plt.yticks(fontsize=7)
    #         plt.tight_layout()
    #         plt.show()

        # print("\nVisualizing FINAL Weighted Fitness Components (Box Plots - Overall):")
        # num_components_final = len(existing_final_weighted_components)
        # cols_final = 3
        # rows_final = (num_components_final + cols_final - 1) // cols_final
        # fig_box_final, axes_box_final = plt.subplots(rows_final, cols_final,
        #                                              figsize=(cols_final * 3.5, rows_final * 3),
        #                                              squeeze=False)
        # axes_box_final = axes_box_final.flatten()
        # for i, component in enumerate(existing_final_weighted_components):
        #     if i < len(axes_box_final):
        #         ax_bf = axes_box_final[i]
        #         data_to_plot_box_f = df[component].replace([np.inf, -np.inf], np.nan).dropna()
        #         if not data_to_plot_box_f.empty:
        #             sns.boxplot(y=data_to_plot_box_f, ax=ax_bf)
        #             ax_bf.set_title(f'{component}', fontsize=8)
        #             ax_bf.set_ylabel('Value', fontsize=7)
        #             ax_bf.set_xticks([])
        #             ax_bf.tick_params(axis='y', labelsize=6)
        #         else:
        #             ax_bf.text(0.5, 0.5, 'No valid data', ha='center', va='center', fontsize=8)
        #             ax_bf.set_title(f'{component}', fontsize=8)
        #             ax_bf.set_xticks([])
        #             ax_bf.set_yticks([])
        # for j in range(num_components_final, len(axes_box_final)):
        #     fig_box_final.delaxes(axes_box_final[j])
        # fig_box_final.suptitle('Box Plots of Final Weighted PSO Components (Overall)', fontsize=12)
        # fig_box_final.subplots_adjust(hspace=0.6, wspace=0.4, top=0.90, bottom=0.1)
        # plt.show()

    
    # if 'total_fitness' in df.columns:
    #     print("\nVisualizing Total Fitness Distribution (Overall):")
    #     plt.figure(figsize=(8, 4))
    #     data_to_plot = df['total_fitness'].replace([np.inf, -np.inf], np.nan).dropna()
    #     if not data_to_plot.empty:
    #         sns.histplot(data_to_plot, kde=True)
    #         plt.title('Distribution of Total Fitness (Overall)', fontsize=10)
    #         plt.xlabel('Total Fitness', fontsize=8)
    #         plt.ylabel('Frequency', fontsize=8)
    #         plt.tick_params(labelsize=7)
    #     else:
    #         plt.text(0.5, 0.5, 'No valid data for total_fitness', ha='center', va='center', fontsize=8)
    #         plt.title('Distribution of Total Fitness (Overall)', fontsize=10)
    #         plt.xticks([])
    #         plt.yticks([])
    #     plt.tight_layout()
    #     plt.show()


if __name__ == '__main__':
    
    csv_file_to_analyze = r"E:\Webots\controllers\pso_rl_supervisor\initial_pso_raw_components.csv"
    
    
    
    
    fitness_history_csv = r"E:\Webots\controllers\pso_rl_supervisor\initial_pso_fitness.csv" 

    print(f"Analyzing main data from: {csv_file_to_analyze}")
    if fitness_history_csv:
        print(f"Attempting to load global best fitness history from: {fitness_history_csv}")
        
    analyze_pso_fitness_components(csv_file_to_analyze, pso_fitness_history_csv_filepath=fitness_history_csv)
